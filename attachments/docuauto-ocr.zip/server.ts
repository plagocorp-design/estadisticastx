import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

interface IncomingImage {
  name?: string;
  mimeType: string;
  base64: string;
}

const OCR_SYSTEM_INSTRUCTION = `Eres un especialista en extracción OCR de documentos vehiculares e identidad de Colombia (Cédula de Ciudadanía, Cédula de Extranjería, Licencia de Tránsito / Tarjeta de Propiedad [TP], Tarjeta de Operación [TO], y consultas RUNT).

Reglas estrictas de extracción:
1. Analiza TODAS las imágenes adjuntas en conjunto e identifica qué documento corresponde a cada índice (0-based).
2. PROPIETARIOS:
   - En la Cédula de Ciudadanía colombiana, combina NOMBRES + APELLIDOS en orden natural (ej: si dice APELLIDOS: "AMAYA HIDALGO" y NOMBRES: "ABEL DARIO", devuelve "ABEL DARIO AMAYA HIDALGO").
   - Si en la Licencia de Tránsito dice "AMAYA HIDALGO ABEL DARIO" y hay una cédula de la misma persona, usa el orden natural NOMBRES + APELLIDOS de la Cédula.
   - Si aparecen varios propietarios distintos (por ejemplo, dos cédulas distintas o copropietarios listados), inclúyelos todos en el arreglo "owners" (el primero será el Propietario Principal y los demás Copropietarios).
   - Para "identificacion", extrae solo el número/código sin puntos ni prefijos (ej: "79.897.980" -> "79897980").
   - Para "tipoDocumento", usa exactamente uno de: "Cédula de Ciudadanía (CC)", "Cédula de Extranjería (CE)", "NIT", "Pasaporte", "Tarjeta de Identidad (TI)".
   - Si teléfono, correo o dirección no aparecen en ninguna foto, déjalos como cadena vacía "". NUNCA inventes datos faltantes.
3. VEHÍCULO Y VALIDACIÓN CON TP (Tarjeta de Propiedad / Licencia de Tránsito):
   - Prioriza la Licencia de Tránsito (TP) como fuente principal para: "clase" (ej. AUTOMOVIL), "linea" (ej. SPARK), "cilindraje" (sin puntos, ej. "1.000" -> "1000"), "numeroMotor", "numeroSerie", "numeroChasis".
   - Prioriza la Tarjeta de Operación (TO) para "empresaTaxiActual" (campo RAZÓN SOCIAL, ej. "TAXEXPRESS SA"), "tarjetaOperacionNo" y "tarjetaOperacionVencimiento". Si no hay Tarjeta de Operación o el vehículo es particular/nuevo sin empresa de taxi visible, devuelve "NINGUNA / VEHÍCULO NUEVO" para "empresaTaxiActual".
   - Normaliza "combustible": si dice "GASGASOL" o "GAS GASOL" devuelve "GAS / GASOLINA".
   - En "crossValidation", reporta los valores literales leídos por separado de TP, TO y CC para poder validar coincidencias.
   - Para "fieldSources", indica brevemente las siglas de los documentos fuente separados por " · " (ej: "CC · TP", "TP", "TO", "TP · TO", o "" si no se encontró).`;

const OCR_RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    owners: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          nombresYApellidos: { type: Type.STRING },
          tipoDocumento: { type: Type.STRING },
          identificacion: { type: Type.STRING },
          telefono: { type: Type.STRING },
          correo: { type: Type.STRING },
          direccion: { type: Type.STRING },
        },
        required: [
          'nombresYApellidos',
          'tipoDocumento',
          'identificacion',
          'telefono',
          'correo',
          'direccion',
        ],
      },
    },
    vehicle: {
      type: Type.OBJECT,
      properties: {
        placa: { type: Type.STRING },
        marca: { type: Type.STRING },
        linea: { type: Type.STRING },
        clase: { type: Type.STRING },
        modelo: { type: Type.STRING },
        numeroMotor: { type: Type.STRING },
        numeroSerie: { type: Type.STRING },
        carroceria: { type: Type.STRING },
        cilindraje: { type: Type.STRING },
        numeroChasis: { type: Type.STRING },
        combustible: { type: Type.STRING },
        empresaTaxiActual: { type: Type.STRING },
      },
      required: [
        'placa',
        'marca',
        'linea',
        'clase',
        'modelo',
        'numeroMotor',
        'numeroSerie',
        'carroceria',
        'cilindraje',
        'numeroChasis',
        'combustible',
        'empresaTaxiActual',
      ],
    },
    extraMetadata: {
      type: Type.OBJECT,
      properties: {
        color: { type: Type.STRING },
        servicio: { type: Type.STRING },
        capacidadPasajeros: { type: Type.STRING },
        limitacionPropiedad: { type: Type.STRING },
        organismoTransito: { type: Type.STRING },
        licenciaTransitoNo: { type: Type.STRING },
        fechaMatricula: { type: Type.STRING },
        tarjetaOperacionNo: { type: Type.STRING },
        tarjetaOperacionVencimiento: { type: Type.STRING },
        modalidad: { type: Type.STRING },
      },
      required: [
        'color',
        'servicio',
        'capacidadPasajeros',
        'limitacionPropiedad',
        'organismoTransito',
        'licenciaTransitoNo',
        'fechaMatricula',
        'tarjetaOperacionNo',
        'tarjetaOperacionVencimiento',
        'modalidad',
      ],
    },
    crossValidation: {
      type: Type.OBJECT,
      properties: {
        hasLicenciaTransito: { type: Type.BOOLEAN },
        hasTarjetaOperacion: { type: Type.BOOLEAN },
        hasCedula: { type: Type.BOOLEAN },
        motorEnTP: { type: Type.STRING },
        motorEnTO: { type: Type.STRING },
        serieEnTP: { type: Type.STRING },
        chasisEnTP: { type: Type.STRING },
        placaEnTP: { type: Type.STRING },
        placaEnTO: { type: Type.STRING },
        propietarioEnCC: { type: Type.STRING },
        propietarioEnTP: { type: Type.STRING },
        identificacionEnCC: { type: Type.STRING },
        identificacionEnTP: { type: Type.STRING },
      },
      required: [
        'hasLicenciaTransito',
        'hasTarjetaOperacion',
        'hasCedula',
        'motorEnTP',
        'motorEnTO',
        'serieEnTP',
        'chasisEnTP',
        'placaEnTP',
        'placaEnTO',
        'propietarioEnCC',
        'propietarioEnTP',
        'identificacionEnCC',
        'identificacionEnTP',
      ],
    },
    documents: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          imageIndex: { type: Type.INTEGER },
          category: { type: Type.STRING },
          label: { type: Type.STRING },
          detectedFieldsCount: { type: Type.INTEGER },
          notes: { type: Type.STRING },
        },
        required: [
          'imageIndex',
          'category',
          'label',
          'detectedFieldsCount',
          'notes',
        ],
      },
    },
    fieldSources: {
      type: Type.OBJECT,
      properties: {
        nombresYApellidos: { type: Type.STRING },
        identificacion: { type: Type.STRING },
        placa: { type: Type.STRING },
        marca: { type: Type.STRING },
        linea: { type: Type.STRING },
        clase: { type: Type.STRING },
        modelo: { type: Type.STRING },
        numeroMotor: { type: Type.STRING },
        numeroSerie: { type: Type.STRING },
        carroceria: { type: Type.STRING },
        cilindraje: { type: Type.STRING },
        numeroChasis: { type: Type.STRING },
        combustible: { type: Type.STRING },
        empresaTaxiActual: { type: Type.STRING },
      },
      required: [
        'nombresYApellidos',
        'identificacion',
        'placa',
        'marca',
        'linea',
        'clase',
        'modelo',
        'numeroMotor',
        'numeroSerie',
        'carroceria',
        'cilindraje',
        'numeroChasis',
        'combustible',
        'empresaTaxiActual',
      ],
    },
  },
  required: [
    'owners',
    'vehicle',
    'extraMetadata',
    'crossValidation',
    'documents',
    'fieldSources',
  ],
};

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY no está configurada en el servidor. Verifique Settings > Secrets.'
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '45mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, hasApiKey: Boolean(process.env.GEMINI_API_KEY) });
  });

  app.post('/api/ocr/extract', async (req, res) => {
    try {
      const images = req.body?.images as IncomingImage[] | undefined;
      if (!Array.isArray(images) || images.length === 0) {
        res.status(400).json({
          error: 'Debe adjuntar al menos una imagen para ejecutar el OCR.',
        });
        return;
      }

      if (images.length > 12) {
        res.status(400).json({
          error: 'Se permite un máximo de 12 imágenes por análisis.',
        });
        return;
      }

      const parts: Array<
        { text: string } | { inlineData: { mimeType: string; data: string } }
      > = [];

      images.forEach((img, idx) => {
        const rawBase64 = img.base64.includes(',')
          ? img.base64.split(',')[1]
          : img.base64;
        parts.push({
          text: `Imagen índice ${idx} (archivo: ${img.name || `documento_${idx + 1}`}):`,
        });
        parts.push({
          inlineData: {
            mimeType: img.mimeType || 'image/jpeg',
            data: rawBase64,
          },
        });
      });

      parts.push({
        text: 'Extrae todos los campos solicitados del propietario(s), características del vehículo, validación cruzada con TP/TO y clasificación de cada imagen en JSON estricto.',
      });

      const ai = getAiClient();

      const sleep = (ms: number) =>
        new Promise((resolve) => setTimeout(resolve, ms));

      const callModelWithTimeout = async (
        modelName: string,
        timeoutMs: number
      ) => {
        const thinkingLevel =
          modelName === 'gemini-3.1-flash-lite'
            ? ThinkingLevel.MINIMAL
            : ThinkingLevel.LOW;

        let timer: ReturnType<typeof setTimeout> | undefined;
        const timeoutPromise = new Promise<never>((_resolve, reject) => {
          timer = setTimeout(() => {
            reject(new Error(`TIMEOUT_ATTEMPT_${modelName}`));
          }, timeoutMs);
        });

        try {
          return await Promise.race([
            ai.models.generateContent({
              model: modelName,
              contents: { parts },
              config: {
                systemInstruction: OCR_SYSTEM_INSTRUCTION,
                responseMimeType: 'application/json',
                responseSchema: OCR_RESPONSE_SCHEMA,
                thinkingConfig: {
                  thinkingLevel,
                },
              },
            }),
            timeoutPromise,
          ]);
        } finally {
          if (timer) clearTimeout(timer);
        }
      };

      const isTransientOrTimeoutError = (err: unknown): boolean => {
        const msg = err instanceof Error ? err.message : String(err);
        return (
          msg.includes('TIMEOUT_ATTEMPT_') ||
          msg.includes('503') ||
          msg.includes('UNAVAILABLE') ||
          msg.includes('high demand') ||
          msg.includes('429') ||
          msg.includes('RESOURCE_EXHAUSTED')
        );
      };

      const attemptSequence = [
        { model: 'gemini-3.1-flash-lite', waitMs: 0, timeoutMs: 22000 },
        { model: 'gemini-4-hydrogen', waitMs: 400, timeoutMs: 22000 },
        { model: 'gemini-3.1-flash-lite', waitMs: 800, timeoutMs: 20000 },
      ];

      let response: Awaited<ReturnType<typeof callModelWithTimeout>> | null =
        null;
      let lastError: unknown = null;

      for (const attempt of attemptSequence) {
        if (attempt.waitMs > 0) {
          await sleep(attempt.waitMs);
        }
        try {
          response = await callModelWithTimeout(
            attempt.model,
            attempt.timeoutMs
          );
          break;
        } catch (err) {
          lastError = err;
          if (!isTransientOrTimeoutError(err)) {
            throw err;
          }
          console.warn(
            `[/api/ocr/extract] Transient/timeout error on ${attempt.model}, retrying...`
          );
        }
      }

      if (!response) {
        throw lastError || new Error('No se obtuvo respuesta del modelo OCR.');
      }

      const rawText = response.text?.trim();
      if (!rawText) {
        res.status(502).json({
          error:
            'El servicio OCR devolvió una respuesta vacía. Intente nuevamente.',
        });
        return;
      }

      const parsed = JSON.parse(rawText);
      res.json({ ok: true, data: parsed });
    } catch (err: unknown) {
      const rawMessage =
        err instanceof Error ? err.message : 'Error inesperado procesando OCR.';
      console.error('[/api/ocr/extract] Error:', err);

      if (
        rawMessage.includes('503') ||
        rawMessage.includes('UNAVAILABLE') ||
        rawMessage.includes('high demand')
      ) {
        res.status(503).json({
          error:
            'El servicio OCR de Gemini está experimentando alta demanda temporal (503). Intente nuevamente en unos segundos.',
        });
        return;
      }

      if (rawMessage.includes('GEMINI_API_KEY')) {
        res.status(500).json({ error: rawMessage });
        return;
      }

      res.status(502).json({ error: rawMessage });
    }
  });

  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
