export type DocumentType =
  | 'Cédula de Ciudadanía (CC)'
  | 'Cédula de Extranjería (CE)'
  | 'NIT'
  | 'Pasaporte'
  | 'Tarjeta de Identidad (TI)';

export type UploadedDocCategory =
  | 'CEDULA_FRENTE'
  | 'CEDULA_REVERSO'
  | 'LICENCIA_TRANSITO_FRENTE'
  | 'LICENCIA_TRANSITO_REVERSO'
  | 'TARJETA_OPERACION'
  | 'OTRO_DOCUMENTO';

export interface OwnerRecord {
  id: string;
  role: 'principal' | 'copropietario';
  nombresYApellidos: string;
  tipoDocumento: DocumentType;
  identificacion: string;
  telefono: string;
  correo: string;
  direccion: string;
  minimized: boolean;
}

export interface VehicleRecord {
  placa: string;
  marca: string;
  linea: string;
  clase: string;
  modelo: string;
  numeroMotor: string;
  numeroSerie: string;
  carroceria: string;
  cilindraje: string;
  numeroChasis: string;
  combustible: string;
  empresaTaxiActual: string;
}

export interface ExtraVehicleMetadata {
  color: string;
  servicio: string;
  capacidadPasajeros: string;
  limitacionPropiedad: string;
  organismoTransito: string;
  licenciaTransitoNo: string;
  fechaMatricula: string;
  tarjetaOperacionNo: string;
  tarjetaOperacionVencimiento: string;
  modalidad: string;
}

export interface CrossValidationSummary {
  hasLicenciaTransito: boolean;
  hasTarjetaOperacion: boolean;
  hasCedula: boolean;
  motorValidadoConTP: boolean;
  serieValidadaConTP: boolean;
  chasisValidadoConTP: boolean;
  placaCoincideEntreDocumentos: boolean;
  motorCoincideEntreTPyTO: boolean;
  propietarioCoincideEntreCCyTP: boolean;
  alerts: string[];
}

export interface FieldProvenance {
  [fieldKey: string]: string; // e.g. "CC · TP", "TP", "TO"
}

export interface ClassifiedDocument {
  imageIndex: number;
  category: UploadedDocCategory;
  label: string;
  detectedFieldsCount: number;
  notes: string;
}

export interface OcrExtractionResult {
  owners: Array<{
    nombresYApellidos: string;
    tipoDocumento: string;
    identificacion: string;
    telefono: string;
    correo: string;
    direccion: string;
  }>;
  vehicle: VehicleRecord;
  extraMetadata: ExtraVehicleMetadata;
  crossValidation: {
    hasLicenciaTransito: boolean;
    hasTarjetaOperacion: boolean;
    hasCedula: boolean;
    motorEnTP: string;
    motorEnTO: string;
    serieEnTP: string;
    chasisEnTP: string;
    placaEnTP: string;
    placaEnTO: string;
    propietarioEnCC: string;
    propietarioEnTP: string;
    identificacionEnCC: string;
    identificacionEnTP: string;
  };
  documents: ClassifiedDocument[];
  fieldSources: FieldProvenance;
}

export interface UploadedImageItem {
  id: string;
  name: string;
  mimeType: string;
  dataUrl: string;
  sizeBytes: number;
  category?: UploadedDocCategory;
  categoryLabel?: string;
  notes?: string;
}

export interface SavedRecord {
  id: string;
  savedAt: string;
  owners: OwnerRecord[];
  vehicle: VehicleRecord;
  extraMetadata: ExtraVehicleMetadata;
  crossValidation: CrossValidationSummary;
}
