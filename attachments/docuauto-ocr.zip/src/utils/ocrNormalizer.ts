import type {
  CrossValidationSummary,
  DocumentType,
  ExtraVehicleMetadata,
  OcrExtractionResult,
  OwnerRecord,
  VehicleRecord,
} from '../types/ocr';

export function normalizeIdentification(raw: string): string {
  const cleaned = raw
    .replace(/C\.?\s*C\.?/gi, '')
    .replace(/N[°o.]?/gi, '')
    .replace(/[.\s,-]/g, '')
    .trim()
    .toUpperCase();
  return cleaned;
}

export function normalizeDocumentType(raw: string): DocumentType {
  const upper = raw.trim().toUpperCase();
  if (upper.includes('EXTRANJ') || upper === 'CE' || upper === 'C.E.') {
    return 'Cédula de Extranjería (CE)';
  }
  if (upper.includes('NIT')) {
    return 'NIT';
  }
  if (upper.includes('PASAPORTE') || upper === 'PA' || upper === 'PP') {
    return 'Pasaporte';
  }
  if (upper.includes('IDENTIDAD') || upper === 'TI' || upper === 'T.I.') {
    return 'Tarjeta de Identidad (TI)';
  }
  return 'Cédula de Ciudadanía (CC)';
}

export function normalizeCilindraje(raw: string): string {
  if (!raw) return '';
  // Colombian TP often prints "1.000" or "1.600" for 1000cc / 1600cc
  const digitsOnly = raw.replace(/[^0-9]/g, '');
  if (!digitsOnly) return raw.trim();
  const numeric = Number.parseInt(digitsOnly, 10);
  return Number.isFinite(numeric) && numeric > 0 ? String(numeric) : digitsOnly;
}

export function normalizeFuelType(raw: string): string {
  const upper = raw.trim().toUpperCase().replace(/\s+/g, ' ');
  if (!upper) return '';
  if (upper === 'GASOLINA' || upper === 'GASOL') {
    return 'GASOLINA';
  }
  if (
    upper.includes('GASGASOL') ||
    upper.includes('GAS GASOL') ||
    upper.includes('GAS-GASOL') ||
    upper.includes('GAS / GASOL') ||
    upper.includes('GAS/GASOL')
  ) {
    return 'GAS / GASOLINA';
  }
  if (upper.includes('GNV') || upper === 'GAS NATURAL' || upper === 'GAS') {
    return 'GNV (GAS NATURAL)';
  }
  if (upper.includes('DIESEL') || upper.includes('ACPM')) {
    return 'DIESEL';
  }
  if (upper.includes('ELECTR')) {
    return 'ELÉCTRICO';
  }
  if (upper.includes('HIBR') || upper.includes('HÍBR')) {
    return 'HÍBRIDO';
  }
  return upper;
}

export function normalizeVehicleClass(raw: string): string {
  const upper = raw.trim().toUpperCase();
  if (!upper) return 'AUTOMOVIL';
  if (upper.includes('AUTOMOVIL') || upper.includes('AUTOMÓVIL')) return 'AUTOMOVIL';
  if (upper.includes('TAXI')) return 'TAXI';
  if (upper.includes('CAMIONETA')) return 'CAMIONETA';
  if (upper.includes('CAMPERO')) return 'CAMPERO';
  if (upper.includes('MICROBUS') || upper.includes('MICROBÚS')) return 'MICROBUS';
  if (upper.includes('BUSETA')) return 'BUSETA';
  if (upper.includes('BUS')) return 'BUS';
  if (upper.includes('MOTO')) return 'MOTOCICLETA';
  if (upper.includes('CAMION') || upper.includes('CAMIÓN')) return 'CAMION';
  return upper;
}

export function normalizePlate(raw: string): string {
  return raw.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
}

export function normalizeSerialCode(raw: string): string {
  return raw.replace(/\s+/g, '').toUpperCase();
}

export function normalizeTokenCompare(nameA: string, nameB: string): boolean {
  const tokenize = (s: string) =>
    s
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toUpperCase()
      .replace(/[^A-Z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(Boolean)
      .sort();

  const tokensA = tokenize(nameA);
  const tokensB = tokenize(nameB);
  if (tokensA.length === 0 || tokensB.length === 0) return false;
  if (tokensA.length !== tokensB.length) return false;
  return tokensA.every((token, idx) => token === tokensB[idx]);
}

export function buildCrossValidation(
  raw: OcrExtractionResult['crossValidation'],
  currentVehicle: VehicleRecord
): CrossValidationSummary {
  const alerts: string[] = [];

  const motorTP = normalizeSerialCode(raw.motorEnTP || '');
  const motorTO = normalizeSerialCode(raw.motorEnTO || '');
  const serieTP = normalizeSerialCode(raw.serieEnTP || '');
  const chasisTP = normalizeSerialCode(raw.chasisEnTP || '');
  const placaTP = normalizePlate(raw.placaEnTP || '');
  const placaTO = normalizePlate(raw.placaEnTO || '');
  const idCC = normalizeIdentification(raw.identificacionEnCC || '');
  const idTP = normalizeIdentification(raw.identificacionEnTP || '');

  const currentMotor = normalizeSerialCode(currentVehicle.numeroMotor);
  const currentSerie = normalizeSerialCode(currentVehicle.numeroSerie);
  const currentChasis = normalizeSerialCode(currentVehicle.numeroChasis);

  const motorValidadoConTP =
    Boolean(raw.hasLicenciaTransito) && Boolean(motorTP) && currentMotor === motorTP;
  const serieValidadaConTP =
    Boolean(raw.hasLicenciaTransito) && Boolean(serieTP) && currentSerie === serieTP;
  const chasisValidadoConTP =
    Boolean(raw.hasLicenciaTransito) && Boolean(chasisTP) && currentChasis === chasisTP;

  const motorCoincideEntreTPyTO =
    motorTP && motorTO ? motorTP === motorTO : true;

  if (motorTP && motorTO && motorTP !== motorTO) {
    alerts.push(
      `Diferencia de N° Motor entre Licencia de Tránsito (${motorTP}) y Tarjeta de Operación (${motorTO}).`
    );
  }

  const placaCoincideEntreDocumentos =
    placaTP && placaTO ? placaTP === placaTO : true;

  if (placaTP && placaTO && placaTP !== placaTO) {
    alerts.push(
      `La placa en Licencia de Tránsito (${placaTP}) no coincide con la Tarjeta de Operación (${placaTO}).`
    );
  }

  const propietarioCoincideEntreCCyTP =
    raw.hasCedula && raw.hasLicenciaTransito
      ? (Boolean(idCC && idTP) && idCC === idTP) ||
        normalizeTokenCompare(raw.propietarioEnCC || '', raw.propietarioEnTP || '')
      : true;

  if (raw.hasCedula && raw.hasLicenciaTransito && !propietarioCoincideEntreCCyTP) {
    alerts.push(
      `El titular de la Cédula (${raw.propietarioEnCC || idCC}) difiere del propietario en la Licencia de Tránsito (${raw.propietarioEnTP || idTP}).`
    );
  }

  if (!raw.hasLicenciaTransito) {
    alerts.push(
      'No se detectó Licencia de Tránsito (TP): valide manualmente N° Motor, N° Serie y N° Chasis con la TP física.'
    );
  }

  return {
    hasLicenciaTransito: Boolean(raw.hasLicenciaTransito),
    hasTarjetaOperacion: Boolean(raw.hasTarjetaOperacion),
    hasCedula: Boolean(raw.hasCedula),
    motorValidadoConTP,
    serieValidadaConTP,
    chasisValidadoConTP,
    placaCoincideEntreDocumentos,
    motorCoincideEntreTPyTO,
    propietarioCoincideEntreCCyTP,
    alerts,
  };
}

export function normalizeExtractionPayload(raw: OcrExtractionResult): {
  owners: OwnerRecord[];
  vehicle: VehicleRecord;
  extraMetadata: ExtraVehicleMetadata;
  crossValidation: CrossValidationSummary;
} {
  const owners: OwnerRecord[] =
    raw.owners && raw.owners.length > 0
      ? raw.owners.map((owner, index) => ({
          id: `owner-${index + 1}`,
          role: index === 0 ? 'principal' : 'copropietario',
          nombresYApellidos: (owner.nombresYApellidos || '').trim().toUpperCase(),
          tipoDocumento: normalizeDocumentType(owner.tipoDocumento || ''),
          identificacion: normalizeIdentification(owner.identificacion || ''),
          telefono: (owner.telefono || '').trim(),
          correo: (owner.correo || '').trim().toLowerCase(),
          direccion: (owner.direccion || '').trim(),
          minimized: false,
        }))
      : [
          {
            id: 'owner-1',
            role: 'principal',
            nombresYApellidos: '',
            tipoDocumento: 'Cédula de Ciudadanía (CC)',
            identificacion: '',
            telefono: '',
            correo: '',
            direccion: '',
            minimized: false,
          },
        ];

  const v = raw.vehicle;
  const vehicle: VehicleRecord = {
    placa: normalizePlate(v.placa || ''),
    marca: (v.marca || '').trim().toUpperCase(),
    linea: (v.linea || '').trim().toUpperCase(),
    clase: normalizeVehicleClass(v.clase || ''),
    modelo: (v.modelo || '').replace(/[^0-9]/g, '').slice(0, 4),
    numeroMotor: normalizeSerialCode(v.numeroMotor || ''),
    numeroSerie: normalizeSerialCode(v.numeroSerie || ''),
    carroceria: (v.carroceria || '').trim().toUpperCase(),
    cilindraje: normalizeCilindraje(v.cilindraje || ''),
    numeroChasis: normalizeSerialCode(v.numeroChasis || ''),
    combustible: normalizeFuelType(v.combustible || ''),
    empresaTaxiActual: (v.empresaTaxiActual || '').trim().toUpperCase() || 'NINGUNA / VEHÍCULO NUEVO',
  };

  const extraMetadata: ExtraVehicleMetadata = {
    color: (raw.extraMetadata?.color || '').trim().toUpperCase(),
    servicio: (raw.extraMetadata?.servicio || '').trim().toUpperCase(),
    capacidadPasajeros: (raw.extraMetadata?.capacidadPasajeros || '').trim(),
    limitacionPropiedad: (raw.extraMetadata?.limitacionPropiedad || '').trim().toUpperCase(),
    organismoTransito: (raw.extraMetadata?.organismoTransito || '').trim().toUpperCase(),
    licenciaTransitoNo: (raw.extraMetadata?.licenciaTransitoNo || '').trim(),
    fechaMatricula: (raw.extraMetadata?.fechaMatricula || '').trim(),
    tarjetaOperacionNo: (raw.extraMetadata?.tarjetaOperacionNo || '').trim(),
    tarjetaOperacionVencimiento: (raw.extraMetadata?.tarjetaOperacionVencimiento || '').trim(),
    modalidad: (raw.extraMetadata?.modalidad || '').trim().toUpperCase(),
  };

  const crossValidation = buildCrossValidation(raw.crossValidation, vehicle);

  return {
    owners,
    vehicle,
    extraMetadata,
    crossValidation,
  };
}

export interface FormValidationError {
  field: string;
  message: string;
}

export function validateContractForm(
  owners: OwnerRecord[],
  vehicle: VehicleRecord
): FormValidationError[] {
  const errors: FormValidationError[] = [];
  const principal = owners[0];

  if (!principal) {
    errors.push({ field: 'owner', message: 'Debe existir al menos un propietario principal.' });
  } else {
    if (!principal.nombresYApellidos.trim()) {
      errors.push({ field: 'nombresYApellidos', message: 'Falta el nombre completo del propietario principal.' });
    }
    if (!principal.identificacion.trim()) {
      errors.push({ field: 'identificacion', message: 'Falta el número de identificación del propietario principal.' });
    }
  }

  owners.slice(1).forEach((co, idx) => {
    if (!co.nombresYApellidos.trim() || !co.identificacion.trim()) {
      errors.push({
        field: `copropietario-${idx + 1}`,
        message: `Complete nombre e identificación del Copropietario ${idx + 1}.`,
      });
    }
  });

  if (!vehicle.placa.trim()) {
    errors.push({ field: 'placa', message: 'Falta la placa del vehículo.' });
  }
  if (!vehicle.marca.trim()) {
    errors.push({ field: 'marca', message: 'Falta la marca del vehículo.' });
  }
  if (!vehicle.numeroMotor.trim()) {
    errors.push({ field: 'numeroMotor', message: 'Falta el N° Motor del vehículo.' });
  }
  if (!vehicle.numeroSerie.trim()) {
    errors.push({ field: 'numeroSerie', message: 'Falta el N° Serie del vehículo.' });
  }

  return errors;
}

export function generateContractSummaryText(
  owners: OwnerRecord[],
  vehicle: VehicleRecord,
  extra: ExtraVehicleMetadata
): string {
  const fecha = new Date().toLocaleDateString('es-CO', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const ownerBlocks = owners
    .map((o, i) => {
      const title = i === 0 ? 'PROPIETARIO PRINCIPAL' : `COPROPIETARIO ${i}`;
      return [
        `${title}: ${o.nombresYApellidos || 'POR DEFINIR'}`,
        `  Documento: ${o.tipoDocumento} N° ${o.identificacion || 'POR DEFINIR'}`,
        `  Teléfono: ${o.telefono || 'No registrado'}`,
        `  Correo: ${o.correo || 'No registrado'}`,
        i === 0 ? `  Dirección de notificaciones: ${o.direccion || 'No registrada'}` : '',
      ]
        .filter(Boolean)
        .join('\n');
    })
    .join('\n\n');

  const lines = [
    'CONTRATO DE VINCULACIÓN Y REGISTRO DE VEHÍCULO',
    `Fecha de emisión: ${fecha}`,
    '',
    '1. IDENTIFICACIÓN DE PROPIETARIO(S)',
    ownerBlocks,
    '',
    '2. CARACTERÍSTICAS DEL VEHÍCULO',
    `  Placa: ${vehicle.placa || 'N/A'}`,
    `  Marca / Línea: ${vehicle.marca || 'N/A'} ${vehicle.linea || ''}`.trimEnd(),
    `  Clase / Carrocería: ${vehicle.clase || 'N/A'} · ${vehicle.carroceria || 'N/A'}`,
    `  Modelo (Año): ${vehicle.modelo || 'N/A'}`,
    `  Cilindraje: ${vehicle.cilindraje ? `${vehicle.cilindraje} cc` : 'N/A'}`,
    `  Combustible: ${vehicle.combustible || 'N/A'}`,
    `  N° Motor (Validado TP): ${vehicle.numeroMotor || 'N/A'}`,
    `  N° Serie (Validado TP): ${vehicle.numeroSerie || 'N/A'}`,
    `  N° Chasis: ${vehicle.numeroChasis || 'N/A'}`,
    `  Empresa de Taxi Actual: ${vehicle.empresaTaxiActual || 'NINGUNA / VEHÍCULO NUEVO'}`,
  ];

  const extraItems: string[] = [];
  if (extra.color) extraItems.push(`  Color: ${extra.color}`);
  if (extra.servicio) extraItems.push(`  Servicio: ${extra.servicio}`);
  if (extra.licenciaTransitoNo) extraItems.push(`  Licencia de Tránsito No.: ${extra.licenciaTransitoNo}`);
  if (extra.tarjetaOperacionNo) {
    extraItems.push(
      `  Tarjeta de Operación No.: ${extra.tarjetaOperacionNo}${
        extra.tarjetaOperacionVencimiento ? ` (Vence: ${extra.tarjetaOperacionVencimiento})` : ''
      }`
    );
  }
  if (extra.limitacionPropiedad) extraItems.push(`  Limitación a la propiedad: ${extra.limitacionPropiedad}`);
  if (extra.organismoTransito) extraItems.push(`  Organismo de Tránsito: ${extra.organismoTransito}`);

  if (extraItems.length > 0) {
    lines.push('', '3. SOPORTE DOCUMENTAL (TP / TO)', ...extraItems);
  }

  return lines.join('\n');
}
