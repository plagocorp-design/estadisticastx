import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildCrossValidation,
  generateContractSummaryText,
  normalizeCilindraje,
  normalizeDocumentType,
  normalizeExtractionPayload,
  normalizeFuelType,
  normalizeIdentification,
  normalizePlate,
  normalizeTokenCompare,
  validateContractForm,
} from './ocrNormalizer';
import type { OcrExtractionResult } from '../types/ocr';

test('normalizes Colombian cédula numbers and document types', () => {
  assert.equal(normalizeIdentification('C.C. 79.897.980'), '79897980');
  assert.equal(normalizeIdentification('79.897.980'), '79897980');
  assert.equal(normalizeDocumentType('CEDULA DE CIUDADANIA'), 'Cédula de Ciudadanía (CC)');
  assert.equal(normalizeDocumentType('CE'), 'Cédula de Extranjería (CE)');
  assert.equal(normalizeDocumentType('NIT'), 'NIT');
});

test('normalizes vehicle cilindraje, plate, and dual fuel codes', () => {
  assert.equal(normalizeCilindraje('1.000'), '1000');
  assert.equal(normalizeCilindraje('1,600 cc'), '1600');
  assert.equal(normalizePlate(' vex-333 '), 'VEX333');
  assert.equal(normalizeFuelType('GASGASOL'), 'GAS / GASOLINA');
  assert.equal(normalizeFuelType('GAS GASOL'), 'GAS / GASOLINA');
  assert.equal(normalizeFuelType('GASOLINA'), 'GASOLINA');
  assert.equal(normalizeFuelType('DIESEL'), 'DIESEL');
});

test('matches owner names regardless of Apellidos-first vs Nombres-first order', () => {
  assert.equal(
    normalizeTokenCompare('ABEL DARIO AMAYA HIDALGO', 'AMAYA HIDALGO ABEL DARIO'),
    true
  );
  assert.equal(
    normalizeTokenCompare('ABEL DARIO AMAYA HIDALGO', 'JUAN CARLOS PEREZ'),
    false
  );
});

test('validates motor and serie against Tarjeta de Propiedad (TP) and detects discrepancies', () => {
  const sampleRaw: OcrExtractionResult = {
    owners: [
      {
        nombresYApellidos: 'ABEL DARIO AMAYA HIDALGO',
        tipoDocumento: 'Cédula de Ciudadanía (CC)',
        identificacion: '79.897.980',
        telefono: '',
        correo: '',
        direccion: '',
      },
    ],
    vehicle: {
      placa: 'VEX333',
      marca: 'CHEVROLET',
      linea: 'SPARK',
      clase: 'AUTOMOVIL',
      modelo: '2009',
      numeroMotor: 'B10S1177064KC2',
      numeroSerie: '9GAMM61019B134535',
      carroceria: 'SEDAN',
      cilindraje: '1.000',
      numeroChasis: '9GAMM61019B134535',
      combustible: 'GASGASOL',
      empresaTaxiActual: 'TAXEXPRESS SA',
    },
    extraMetadata: {
      color: 'AMARILLO',
      servicio: 'PÚBLICO',
      capacidadPasajeros: '5',
      limitacionPropiedad: 'PRENDA - GLOBAL DATOS NACIONALES S.A',
      organismoTransito: 'SDM - BOGOTA D.C.',
      licenciaTransitoNo: '10012323419',
      fechaMatricula: '21/01/2009',
      tarjetaOperacionNo: '2144364',
      tarjetaOperacionVencimiento: '19/02/2027',
      modalidad: 'PASAJEROS',
    },
    crossValidation: {
      hasLicenciaTransito: true,
      hasTarjetaOperacion: true,
      hasCedula: true,
      motorEnTP: 'B10S1177064KC2',
      motorEnTO: 'B10S1177064KC2',
      serieEnTP: '9GAMM61019B134535',
      chasisEnTP: '9GAMM61019B134535',
      placaEnTP: 'VEX333',
      placaEnTO: 'VEX333',
      propietarioEnCC: 'ABEL DARIO AMAYA HIDALGO',
      propietarioEnTP: 'AMAYA HIDALGO ABEL DARIO',
      identificacionEnCC: '79.897.980',
      identificacionEnTP: 'C.C. 79897980',
    },
    documents: [],
    fieldSources: {},
  };

  const normalized = normalizeExtractionPayload(sampleRaw);
  assert.equal(normalized.owners[0].identificacion, '79897980');
  assert.equal(normalized.vehicle.cilindraje, '1000');
  assert.equal(normalized.vehicle.combustible, 'GAS / GASOLINA');
  assert.equal(normalized.crossValidation.motorValidadoConTP, true);
  assert.equal(normalized.crossValidation.serieValidadaConTP, true);
  assert.equal(normalized.crossValidation.propietarioCoincideEntreCCyTP, true);
  assert.equal(normalized.crossValidation.alerts.length, 0);

  // Discrepancy case: TO motor differs from TP motor
  const mismatch = buildCrossValidation(
    {
      ...sampleRaw.crossValidation,
      motorEnTO: 'B10S9999999KC2',
    },
    normalized.vehicle
  );
  assert.equal(mismatch.motorCoincideEntreTPyTO, false);
  assert.equal(mismatch.alerts.length, 1);
});

test('validates required contract form fields and generates clean contract summary', () => {
  const emptyErrors = validateContractForm(
    [
      {
        id: 'owner-1',
        role: 'principal',
        nombresYApellidos: '',
        tipoDocumento: 'Cédula de Ciudadanía (CC)',
        identificacion: '',
        telefono: '',
        correo: '',
        direccion: '',
        minimized: false,
      },
    ],
    {
      placa: '',
      marca: '',
      linea: '',
      clase: 'AUTOMOVIL',
      modelo: '',
      numeroMotor: '',
      numeroSerie: '',
      carroceria: '',
      cilindraje: '',
      numeroChasis: '',
      combustible: '',
      empresaTaxiActual: 'NINGUNA / VEHÍCULO NUEVO',
    }
  );
  assert.ok(emptyErrors.length >= 6);

  const summary = generateContractSummaryText(
    [
      {
        id: 'owner-1',
        role: 'principal',
        nombresYApellidos: 'ABEL DARIO AMAYA HIDALGO',
        tipoDocumento: 'Cédula de Ciudadanía (CC)',
        identificacion: '79897980',
        telefono: '3001234567',
        correo: 'abel@ejemplo.com',
        direccion: 'Calle 100 # 15-20',
        minimized: false,
      },
    ],
    {
      placa: 'VEX333',
      marca: 'CHEVROLET',
      linea: 'SPARK',
      clase: 'AUTOMOVIL',
      modelo: '2009',
      numeroMotor: 'B10S1177064KC2',
      numeroSerie: '9GAMM61019B134535',
      carroceria: 'SEDAN',
      cilindraje: '1000',
      numeroChasis: '9GAMM61019B134535',
      combustible: 'GAS / GASOLINA',
      empresaTaxiActual: 'TAXEXPRESS SA',
    },
    {
      color: 'AMARILLO',
      servicio: 'PÚBLICO',
      capacidadPasajeros: '5',
      limitacionPropiedad: 'PRENDA - GLOBAL DATOS NACIONALES S.A',
      organismoTransito: 'SDM - BOGOTA D.C.',
      licenciaTransitoNo: '10012323419',
      fechaMatricula: '21/01/2009',
      tarjetaOperacionNo: '2144364',
      tarjetaOperacionVencimiento: '19/02/2027',
      modalidad: 'PASAJEROS',
    }
  );
  assert.match(summary, /ABEL DARIO AMAYA HIDALGO/);
  assert.match(summary, /VEX333/);
  assert.match(summary, /TAXEXPRESS SA/);
  assert.match(summary, /2144364/);
});
