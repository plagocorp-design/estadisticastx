import React, { useCallback, useEffect, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  FileText,
  RotateCcw,
} from 'lucide-react';
import { ContractModal } from './components/ContractModal';
import { DocumentDropzone } from './components/DocumentDropzone';
import { HistoryView } from './components/HistoryView';
import { OwnerSection } from './components/OwnerSection';
import { RulesView } from './components/RulesView';
import { VehicleSection } from './components/VehicleSection';
import { SAMPLE_CASE_PHOTOS } from './data/catalogs';
import type {
  CrossValidationSummary,
  ExtraVehicleMetadata,
  FieldProvenance,
  OcrExtractionResult,
  OwnerRecord,
  SavedRecord,
  UploadedImageItem,
  VehicleRecord,
} from './types/ocr';
import {
  buildCrossValidation,
  normalizeExtractionPayload,
  validateContractForm,
} from './utils/ocrNormalizer';

type ActiveTab = 'workspace' | 'history' | 'rules';

const STORAGE_KEY = 'docuauto_ocr_history_v1';

function createInitialOwner(): OwnerRecord {
  return {
    id: 'owner-1',
    role: 'principal',
    nombresYApellidos: '',
    tipoDocumento: 'Cédula de Ciudadanía (CC)',
    identificacion: '',
    telefono: '',
    correo: '',
    direccion: '',
    minimized: false,
  };
}

function createInitialVehicle(): VehicleRecord {
  return {
    placa: '',
    marca: '',
    linea: '',
    clase: 'AUTOMOVIL',
    modelo: '',
    numeroMotor: '',
    numeroSerie: '',
    carroceria: '',
    cilindraje: '',
    numeroChasis: '',
    combustible: '',
    empresaTaxiActual: 'NINGUNA / VEHÍCULO NUEVO',
  };
}

function createInitialExtra(): ExtraVehicleMetadata {
  return {
    color: '',
    servicio: '',
    capacidadPasajeros: '',
    limitacionPropiedad: '',
    organismoTransito: '',
    licenciaTransitoNo: '',
    fechaMatricula: '',
    tarjetaOperacionNo: '',
    tarjetaOperacionVencimiento: '',
    modalidad: '',
  };
}

function createInitialCrossValidation(): CrossValidationSummary {
  return {
    hasLicenciaTransito: false,
    hasTarjetaOperacion: false,
    hasCedula: false,
    motorValidadoConTP: false,
    serieValidadaConTP: false,
    chasisValidadoConTP: false,
    placaCoincideEntreDocumentos: true,
    motorCoincideEntreTPyTO: true,
    propietarioCoincideEntreCCyTP: true,
    alerts: [],
  };
}

function readFileAsDataUrl(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('No se pudo leer el archivo de imagen.'));
    reader.readAsDataURL(file);
  });
}

function compressImageForOcr(
  dataUrl: string,
  mimeType: string
): Promise<{ base64: string; mimeType: string }> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const maxDim = 1400;
      const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
      const targetW = Math.max(1, Math.round(img.width * scale));
      const targetH = Math.max(1, Math.round(img.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve({ base64: dataUrl, mimeType });
        return;
      }
      ctx.drawImage(img, 0, 0, targetW, targetH);
      const compressedUrl = canvas.toDataURL('image/jpeg', 0.85);
      resolve({ base64: compressedUrl, mimeType: 'image/jpeg' });
    };
    img.onerror = () => resolve({ base64: dataUrl, mimeType });
    img.src = dataUrl;
  });
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('workspace');
  const [images, setImages] = useState<UploadedImageItem[]>([]);
  const [selectedImageId, setSelectedImageId] = useState<string | null>(null);

  const [owners, setOwners] = useState<OwnerRecord[]>([createInitialOwner()]);
  const [vehicle, setVehicle] = useState<VehicleRecord>(createInitialVehicle());
  const [extraMetadata, setExtraMetadata] = useState<ExtraVehicleMetadata>(
    createInitialExtra()
  );
  const [rawCrossBaseline, setRawCrossBaseline] = useState<
    OcrExtractionResult['crossValidation'] | null
  >(null);
  const [crossValidation, setCrossValidation] = useState<CrossValidationSummary>(
    createInitialCrossValidation()
  );
  const [fieldSources, setFieldSources] = useState<FieldProvenance>({});

  const [isLoadingSample, setIsLoadingSample] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [hasExtracted, setHasExtracted] = useState(false);
  const [ocrError, setOcrError] = useState<string | null>(null);
  const [formErrors, setFormErrors] = useState<string[]>([]);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);
  const [contractOpen, setContractOpen] = useState(false);

  const [history, setHistory] = useState<SavedRecord[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? (JSON.parse(raw) as SavedRecord[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    } catch {
      // Ignore storage quota errors
    }
  }, [history]);

  const handleAddFiles = useCallback(async (fileList: FileList | File[]) => {
    const files = Array.from(fileList).filter((f) => f.type.startsWith('image/'));
    if (files.length === 0) return;

    setOcrError(null);
    const created: UploadedImageItem[] = [];
    for (const file of files) {
      const dataUrl = await readFileAsDataUrl(file);
      created.push({
        id: `img-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        name: file.name || 'imagen_pegada.png',
        mimeType: file.type || 'image/jpeg',
        dataUrl,
        sizeBytes: file.size,
      });
    }

    setImages((prev) => {
      const next = [...prev, ...created];
      if (!selectedImageId && next.length > 0) {
        setSelectedImageId(next[0].id);
      }
      return next;
    });
  }, [selectedImageId]);

  // Support Ctrl+V image paste directly in workspace
  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      if (activeTab !== 'workspace') return;
      const items = e.clipboardData?.items;
      if (!items) return;
      const pastedFiles: File[] = [];
      for (const item of Array.from(items)) {
        if (item.type.startsWith('image/')) {
          const f = item.getAsFile();
          if (f) pastedFiles.push(f);
        }
      }
      if (pastedFiles.length > 0) {
        void handleAddFiles(pastedFiles);
      }
    };
    window.addEventListener('paste', onPaste);
    return () => window.removeEventListener('paste', onPaste);
  }, [activeTab, handleAddFiles]);

  const handleLoadSamplePhotos = async () => {
    setIsLoadingSample(true);
    setOcrError(null);
    setStatusNotice(null);
    try {
      const loaded: UploadedImageItem[] = [];
      for (const sample of SAMPLE_CASE_PHOTOS) {
        const res = await fetch(sample.url);
        if (!res.ok) {
          throw new Error(`No se pudo cargar la imagen de ejemplo ${sample.name}`);
        }
        const blob = await res.blob();
        const dataUrl = await readFileAsDataUrl(blob);
        loaded.push({
          id: `sample-${sample.name}-${Date.now()}`,
          name: sample.name,
          mimeType: blob.type || 'image/jpeg',
          dataUrl,
          sizeBytes: blob.size,
          categoryLabel: sample.hint,
        });
      }
      setImages(loaded);
      setSelectedImageId(loaded[0]?.id || null);
      setStatusNotice(
        'Se cargaron las 5 fotos de ejemplo (Cédula, Licencia de Tránsito TP y Tarjeta de Operación). Haga clic en "Extraer Datos con OCR".'
      );
    } catch (err) {
      setOcrError(
        err instanceof Error ? err.message : 'Error cargando fotos de ejemplo.'
      );
    } finally {
      setIsLoadingSample(false);
    }
  };

  const handleRunOcr = async () => {
    if (images.length === 0) return;
    setIsExtracting(true);
    setOcrError(null);
    setFormErrors([]);
    setStatusNotice(null);

    try {
      const optimizedImages = await Promise.all(
        images.map(async (img) => {
          const optimized = await compressImageForOcr(img.dataUrl, img.mimeType);
          return {
            name: img.name,
            mimeType: optimized.mimeType,
            base64: optimized.base64,
          };
        })
      );

      const res = await fetch('/api/ocr/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ images: optimizedImages }),
      });

      const rawResponseText = await res.text();
      let json: { ok?: boolean; error?: string; data?: OcrExtractionResult } | null =
        null;
      try {
        json = JSON.parse(rawResponseText);
      } catch {
        throw new Error(
          `El servidor respondió con un formato inesperado (HTTP ${res.status}). Intente nuevamente.`
        );
      }

      if (!res.ok || !json?.ok || !json.data) {
        throw new Error(
          json?.error || `No se pudo completar la extracción OCR (HTTP ${res.status}).`
        );
      }

      const rawResult = json.data;
      const normalized = normalizeExtractionPayload(rawResult);

      setOwners(normalized.owners);
      setVehicle(normalized.vehicle);
      setExtraMetadata(normalized.extraMetadata);
      setRawCrossBaseline(rawResult.crossValidation);
      setCrossValidation(normalized.crossValidation);
      setFieldSources(rawResult.fieldSources || {});
      setHasExtracted(true);

      // Annotate uploaded images with detected document classifications
      if (Array.isArray(rawResult.documents)) {
        setImages((prev) =>
          prev.map((img, idx) => {
            const match = rawResult.documents.find((d) => d.imageIndex === idx);
            if (!match) return img;
            return {
              ...img,
              category: match.category,
              categoryLabel: match.label || img.categoryLabel,
              notes: match.notes,
            };
          })
        );
      }

      setStatusNotice(
        `Extracción completada sobre ${images.length} documentos. Verifique los campos marcados con *Validar con TP y complete los datos de contacto.`
      );
    } catch (err) {
      setOcrError(
        err instanceof Error ? err.message : 'Error ejecutando el análisis OCR.'
      );
    } finally {
      setIsExtracting(false);
    }
  };

  const handleResetAll = () => {
    setImages([]);
    setSelectedImageId(null);
    setOwners([createInitialOwner()]);
    setVehicle(createInitialVehicle());
    setExtraMetadata(createInitialExtra());
    setRawCrossBaseline(null);
    setCrossValidation(createInitialCrossValidation());
    setFieldSources({});
    setHasExtracted(false);
    setOcrError(null);
    setFormErrors([]);
    setStatusNotice(null);
  };

  const handleAddCoOwner = () => {
    setOwners((prev) => [
      ...prev,
      {
        id: `owner-${Date.now()}-${prev.length + 1}`,
        role: 'copropietario',
        nombresYApellidos: '',
        tipoDocumento: 'Cédula de Ciudadanía (CC)',
        identificacion: '',
        telefono: '',
        correo: '',
        direccion: '',
        minimized: false,
      },
    ]);
  };

  const handleRemoveCoOwner = (id: string) => {
    setOwners((prev) => prev.filter((o) => o.id !== id));
  };

  const handleToggleMinimize = (id: string) => {
    setOwners((prev) =>
      prev.map((o) => (o.id === id ? { ...o, minimized: !o.minimized } : o))
    );
  };

  const handleUpdateOwner = (id: string, patch: Partial<OwnerRecord>) => {
    setOwners((prev) =>
      prev.map((o) => (o.id === id ? { ...o, ...patch } : o))
    );
  };

  const handleUpdateVehicle = (patch: Partial<VehicleRecord>) => {
    setVehicle((prev) => {
      const next = { ...prev, ...patch };
      if (rawCrossBaseline) {
        setCrossValidation(buildCrossValidation(rawCrossBaseline, next));
      }
      return next;
    });
  };

  const handleGenerateContract = (e: React.FormEvent) => {
    e.preventDefault();
    const errors = validateContractForm(owners, vehicle);
    if (errors.length > 0) {
      setFormErrors(errors.map((err) => err.message));
      return;
    }

    setFormErrors([]);
    const record: SavedRecord = {
      id: `rec-${Date.now()}`,
      savedAt: new Date().toISOString(),
      owners,
      vehicle,
      extraMetadata,
      crossValidation,
    };
    setHistory((prev) => [record, ...prev.slice(0, 29)]);
    setContractOpen(true);
  };

  const handleLoadSavedRecord = (record: SavedRecord) => {
    setOwners(record.owners);
    setVehicle(record.vehicle);
    setExtraMetadata(record.extraMetadata);
    setCrossValidation(record.crossValidation);
    setHasExtracted(true);
    setFormErrors([]);
    setActiveTab('workspace');
    setStatusNotice(`Registro cargado para placa ${record.vehicle.placa}.`);
  };

  const handleDeleteSavedRecord = (id: string) => {
    setHistory((prev) => prev.filter((r) => r.id !== id));
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Top Bar Contract: 3 zones (Brand | Single-line Nav | 1 Primary CTA) */}
      <header className="no-print sm:sticky sm:top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-[1440px] flex-wrap sm:flex-nowrap items-center justify-between gap-x-4 gap-y-2 sm:gap-8 px-4 sm:px-6 py-3">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('workspace');
            }}
            className="text-base sm:text-lg font-bold tracking-tight text-slate-950 whitespace-nowrap shrink-0"
          >
            DocuAuto OCR
          </a>

          <nav
            aria-label="Navegación principal"
            className="order-3 sm:order-2 flex w-full sm:w-auto items-center gap-4 sm:gap-6 overflow-x-auto text-xs sm:text-sm font-medium text-slate-600 pt-1 sm:pt-0 border-t sm:border-t-0 border-slate-100"
          >
            <button
              type="button"
              onClick={() => setActiveTab('workspace')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === 'workspace'
                  ? 'border-blue-700 text-slate-950 font-semibold'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Espacio de Trabajo
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === 'history'
                  ? 'border-blue-700 text-slate-950 font-semibold'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Historial ({history.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('rules')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === 'rules'
                  ? 'border-blue-700 text-slate-950 font-semibold'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Reglas TP / TO
            </button>
          </nav>

          <div className="order-2 sm:order-3 shrink-0">
            <button
              type="button"
              onClick={() => {
                handleResetAll();
                setActiveTab('workspace');
              }}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 sm:px-4 py-1.5 sm:py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Nuevo Trámite
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="no-print mx-auto w-full max-w-[1440px] flex-1 px-6 py-7">
        {activeTab === 'workspace' && (
          <div className="space-y-6">
            {/* Compact Workspace Title & Metadata Summary */}
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold tracking-tight text-slate-950 text-balance">
                  Extracción OCR y Diligenciamiento de Contrato Vehicular
                </h1>
                <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                  <span>Cédula de Ciudadanía (CC)</span>
                  <span aria-hidden="true">·</span>
                  <span>Licencia de Tránsito (TP)</span>
                  <span aria-hidden="true">·</span>
                  <span>Tarjeta de Operación (TO)</span>
                </div>
              </div>

              {hasExtracted && (
                <div className="flex items-center gap-3 text-xs font-medium text-emerald-700">
                  <CheckCircle2 className="h-4 w-4 shrink-0" />
                  <span>
                    OCR aplicado · {owners.length}{' '}
                    {owners.length === 1 ? 'propietario' : 'propietarios'} · Placa{' '}
                    <span className="font-mono font-semibold">
                      {vehicle.placa || 'N/A'}
                    </span>
                  </span>
                </div>
              )}
            </div>

            {/* Global Feedback Banners */}
            {ocrError && (
              <div
                role="alert"
                className="flex items-start gap-2.5 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-800"
              >
                <AlertCircle className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">Error en análisis OCR</p>
                  <p className="mt-0.5">{ocrError}</p>
                </div>
              </div>
            )}

            {statusNotice && !ocrError && (
              <div
                role="status"
                className="flex items-start gap-2.5 rounded-lg border border-blue-200 bg-blue-50/70 px-4 py-3 text-xs text-blue-900"
              >
                <CheckCircle2 className="h-4 w-4 text-blue-700 shrink-0 mt-0.5" />
                <p>{statusNotice}</p>
              </div>
            )}

            {/* 2-Column Split Workspace */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-7 items-start">
              {/* Left Column: Document Upload & Inspector */}
              <div className="lg:col-span-5">
                <DocumentDropzone
                  images={images}
                  selectedImageId={selectedImageId}
                  onSelectImage={setSelectedImageId}
                  onAddFiles={handleAddFiles}
                  onRemoveImage={(id) => {
                    setImages((prev) => {
                      const next = prev.filter((img) => img.id !== id);
                      if (selectedImageId === id) {
                        setSelectedImageId(next[0]?.id || null);
                      }
                      return next;
                    });
                  }}
                  onClearImages={() => {
                    setImages([]);
                    setSelectedImageId(null);
                  }}
                  onLoadSamplePhotos={handleLoadSamplePhotos}
                  onRunOcr={handleRunOcr}
                  isLoadingSample={isLoadingSample}
                  isExtracting={isExtracting}
                />
              </div>

              {/* Right Column: Target Registration & Contract Form */}
              <form
                onSubmit={handleGenerateContract}
                className="lg:col-span-7 space-y-8"
                noValidate
              >
                <OwnerSection
                  owners={owners}
                  fieldSources={fieldSources}
                  hasExtracted={hasExtracted}
                  onAddCoOwner={handleAddCoOwner}
                  onRemoveCoOwner={handleRemoveCoOwner}
                  onToggleMinimize={handleToggleMinimize}
                  onUpdateOwner={handleUpdateOwner}
                />

                <VehicleSection
                  vehicle={vehicle}
                  extraMetadata={extraMetadata}
                  crossValidation={crossValidation}
                  fieldSources={fieldSources}
                  hasExtracted={hasExtracted}
                  onUpdateVehicle={handleUpdateVehicle}
                  onUpdateExtra={(patch) =>
                    setExtraMetadata((prev) => ({ ...prev, ...patch }))
                  }
                />

                {/* Form Validation Errors */}
                {formErrors.length > 0 && (
                  <div
                    role="alert"
                    className="rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-800 space-y-1"
                  >
                    <p className="font-semibold">
                      Complete los campos obligatorios antes de generar el contrato:
                    </p>
                    <ul className="list-disc pl-5 space-y-0.5">
                      {formErrors.map((msg, idx) => (
                        <li key={idx}>{msg}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Form Action Footer */}
                <div className="flex flex-wrap items-center justify-between gap-4 border-t border-slate-200 pt-5">
                  <button
                    type="button"
                    onClick={handleResetAll}
                    className="rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
                  >
                    Limpiar Formulario
                  </button>

                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-6 py-2.5 text-sm font-semibold text-white hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
                  >
                    <FileText className="h-4 w-4" />
                    Generar Contrato
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <HistoryView
            records={history}
            onLoadRecord={handleLoadSavedRecord}
            onDeleteRecord={handleDeleteSavedRecord}
          />
        )}

        {activeTab === 'rules' && <RulesView />}
      </main>

      <ContractModal
        open={contractOpen}
        onClose={() => setContractOpen(false)}
        owners={owners}
        vehicle={vehicle}
        extraMetadata={extraMetadata}
        crossValidation={crossValidation}
      />
    </div>
  );
}
