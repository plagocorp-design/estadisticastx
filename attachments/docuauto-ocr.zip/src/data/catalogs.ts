import type { DocumentType } from '../types/ocr';

export const DOCUMENT_TYPE_OPTIONS: DocumentType[] = [
  'Cédula de Ciudadanía (CC)',
  'Cédula de Extranjería (CE)',
  'NIT',
  'Pasaporte',
  'Tarjeta de Identidad (TI)',
];

export const VEHICLE_CLASS_OPTIONS: string[] = [
  'AUTOMOVIL',
  'TAXI',
  'CAMIONETA',
  'CAMPERO',
  'MICROBUS',
  'BUSETA',
  'BUS',
  'MOTOCICLETA',
  'CAMION',
];

export const VEHICLE_BRAND_OPTIONS: string[] = [
  'CHEVROLET',
  'HYUNDAI',
  'KIA',
  'RENAULT',
  'NISSAN',
  'SUZUKI',
  'TOYOTA',
  'MAZDA',
  'VOLKSWAGEN',
  'BYD',
  'JAC',
  'FORD',
  'BAIC',
  'CHERY',
];

export const VEHICLE_LINE_OPTIONS: string[] = [
  'SPARK',
  'SPARK GT',
  'SPARK LIFE',
  'SAIL',
  'ONIX',
  'GRAND I10',
  'I10',
  'ACCENT',
  'PICANTO',
  'EKOTAXI',
  'RIO',
  'LOGAN',
  'SANDERO',
  'KWID',
  'MARCH',
  'VERSA',
  'ALTO',
  'CELERIO',
  'DZIRE',
  'E5',
];

export const VEHICLE_BODY_OPTIONS: string[] = [
  'SEDAN',
  'HATCHBACK',
  'STATION WAGON',
  'CABINADO',
  'DOBLE CABINA',
  'PANEL',
  'VAN',
  'CERRADA',
];

export const VEHICLE_FUEL_OPTIONS: string[] = [
  'GASOLINA',
  'GAS / GASOLINA',
  'GNV (GAS NATURAL)',
  'DIESEL',
  'ELÉCTRICO',
  'HÍBRIDO',
];

export const TAXI_COMPANY_OPTIONS: string[] = [
  'NINGUNA / VEHÍCULO NUEVO',
  'TAXEXPRESS SA',
  'TAXI LIBRES',
  'RADIO TAXI AEROPUERTO',
  'TAXIS VERDES',
  'AUTO TAXI',
  'COOTAX',
  'COPETRAN',
  'MEGA TAXI',
  'TAXI IMPERIAL',
  'TELETAXIS',
];

export interface SamplePhotoAsset {
  url: string;
  name: string;
  hint: string;
}

export const SAMPLE_CASE_PHOTOS: SamplePhotoAsset[] = [
  {
    url: '/assets/aistudio/WhatsApp_Image_2026-11-18_at_9.41.33_AM_c29bb526.jpeg',
    name: '01_cedula_frente.jpeg',
    hint: 'Cédula Frente',
  },
  {
    url: '/assets/aistudio/WhatsApp_Image_2026-11-18_at_9.41.43_AM_002aed46.jpeg',
    name: '02_cedula_reverso.jpeg',
    hint: 'Cédula Reverso',
  },
  {
    url: '/assets/aistudio/WhatsApp_Image_2026-11-18_at_9.39.47_AM_53e47c2d.jpeg',
    name: '03_licencia_transito_tp_frente.jpeg',
    hint: 'Licencia Tránsito (TP) Frente',
  },
  {
    url: '/assets/aistudio/WhatsApp_Image_2026-11-18_at_9.39.47_AM__1__7af7fb12.jpeg',
    name: '04_licencia_transito_tp_reverso.jpeg',
    hint: 'Licencia Tránsito (TP) Reverso',
  },
  {
    url: '/assets/aistudio/WhatsApp_Image_2026-11-18_at_9.40.18_AM_398d7ec8.jpeg',
    name: '05_tarjeta_operacion.jpeg',
    hint: 'Tarjeta de Operación (TO)',
  },
];
