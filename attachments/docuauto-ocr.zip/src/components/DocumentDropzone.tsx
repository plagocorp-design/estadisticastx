import React, { useRef, useState } from 'react';
import {
  Eye,
  FileImage,
  Loader2,
  RotateCw,
  ScanText,
  Sparkles,
  Trash2,
  Upload,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import type { UploadedImageItem } from '../types/ocr';

interface DocumentDropzoneProps {
  images: UploadedImageItem[];
  selectedImageId: string | null;
  onSelectImage: (id: string) => void;
  onAddFiles: (files: FileList | File[]) => void;
  onRemoveImage: (id: string) => void;
  onClearImages: () => void;
  onLoadSamplePhotos: () => void;
  onRunOcr: () => void;
  isLoadingSample: boolean;
  isExtracting: boolean;
}

export function DocumentDropzone({
  images,
  selectedImageId,
  onSelectImage,
  onAddFiles,
  onRemoveImage,
  onClearImages,
  onLoadSamplePhotos,
  onRunOcr,
  isLoadingSample,
  isExtracting,
}: DocumentDropzoneProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);

  const activeImage =
    images.find((img) => img.id === selectedImageId) || images[0] || null;

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onAddFiles(e.dataTransfer.files);
    }
  };

  const formatBytes = (bytes: number) => {
    if (!bytes) return '0 KB';
    const kb = Math.round(bytes / 1024);
    return kb >= 1024 ? `${(kb / 1024).toFixed(1)} MB` : `${kb} KB`;
  };

  return (
    <aside className="flex flex-col gap-5">
      {/* Intake Dropzone */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex items-start justify-between gap-3 mb-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Documentos del Trámite
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Suba fotos de Cédula, Licencia de Tránsito (TP) y Tarjeta de Operación (TO).
            </p>
          </div>
          {images.length > 0 && (
            <button
              type="button"
              onClick={onClearImages}
              className="text-xs font-medium text-slate-500 hover:text-rose-600 transition-colors whitespace-nowrap shrink-0"
            >
              Vaciar fotos
            </button>
          )}
        </div>

        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`rounded-lg border-2 border-dashed p-5 text-center transition-colors ${
            isDragging
              ? 'border-blue-600 bg-blue-50/60'
              : 'border-slate-300 bg-slate-50/60 hover:border-slate-400'
          }`}
        >
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files.length > 0) {
                onAddFiles(e.target.files);
                e.target.value = '';
              }
            }}
          />

          <Upload className="mx-auto h-7 w-7 text-slate-400 mb-2" />
          <p className="text-sm font-medium text-slate-800">
            Arrastre las fotos aquí o seleccione desde su equipo
          </p>
          <p className="text-xs text-slate-500 mt-1">
            JPG, PNG o WEBP · También puede pegar imágenes con Ctrl+V
          </p>

          <div className="mt-4 flex flex-wrap items-center justify-center gap-2.5">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
            >
              <FileImage className="h-4 w-4 text-slate-600" />
              Seleccionar Fotos
            </button>

            <button
              type="button"
              onClick={onLoadSamplePhotos}
              disabled={isLoadingSample || isExtracting}
              className="inline-flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50/70 px-4 py-2 text-xs font-semibold text-blue-800 hover:bg-blue-100/80 disabled:opacity-60 transition-colors whitespace-nowrap shrink-0"
            >
              {isLoadingSample ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="h-4 w-4" />
              )}
              Cargar 5 Fotos de Ejemplo
            </button>
          </div>
        </div>

        {/* Primary OCR Run CTA */}
        <div className="mt-4 flex items-center justify-between gap-3">
          <span className="text-xs text-slate-500 tabular-nums">
            {images.length === 0
              ? 'Sin imágenes cargadas'
              : `${images.length} ${images.length === 1 ? 'imagen lista' : 'imágenes listas'}`}
          </span>

          <button
            type="button"
            onClick={onRunOcr}
            disabled={images.length === 0 || isExtracting}
            className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 disabled:cursor-not-allowed disabled:bg-slate-300 transition-colors whitespace-nowrap shrink-0"
          >
            {isExtracting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Analizando Documentos...
              </>
            ) : (
              <>
                <ScanText className="h-4 w-4" />
                Extraer Datos con OCR
              </>
            )}
          </button>
        </div>
      </div>

      {/* Uploaded Queue List */}
      {images.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-slate-900">
              Imágenes Cargadas ({images.length})
            </h3>
            <span className="text-xs text-slate-500">
              Haga clic para inspeccionar
            </span>
          </div>

          <ul className="divide-y divide-slate-100" data-testid="uploaded-images-list">
            {images.map((img, index) => {
              const isActive = activeImage?.id === img.id;
              return (
                <li
                  key={img.id}
                  className={`flex items-center justify-between gap-3 py-2.5 px-2 rounded-lg transition-colors ${
                    isActive ? 'bg-blue-50/70' : 'hover:bg-slate-50'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      onSelectImage(img.id);
                      setZoom(1);
                      setRotation(0);
                    }}
                    className="flex min-w-0 flex-1 items-center gap-3 text-left"
                  >
                    <img
                      src={img.dataUrl}
                      alt={img.name}
                      referrerPolicy="no-referrer"
                      className="h-12 w-12 shrink-0 rounded-md border border-slate-200 object-cover bg-slate-100"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-900">
                        {index + 1}. {img.categoryLabel || img.name}
                      </p>
                      <p className="truncate text-xs text-slate-500">
                        {img.name} · {formatBytes(img.sizeBytes)}
                      </p>
                    </div>
                  </button>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        onSelectImage(img.id);
                        setZoom(1);
                        setRotation(0);
                      }}
                      aria-label={`Ver ${img.name}`}
                      className="rounded p-1.5 text-slate-500 hover:bg-white hover:text-blue-700"
                    >
                      <Eye className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onRemoveImage(img.id)}
                      aria-label={`Eliminar ${img.name}`}
                      className="rounded p-1.5 text-slate-400 hover:bg-white hover:text-rose-600"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {/* High-Resolution Inspector */}
      {activeImage && (
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between gap-2 mb-3">
            <div className="min-w-0">
              <h3 className="truncate text-sm font-semibold text-slate-900">
                Visor de Validación
              </h3>
              <p className="truncate text-xs text-slate-500">
                {activeImage.categoryLabel || activeImage.name}
              </p>
            </div>

            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={() => setZoom((z) => Math.max(1, Number((z - 0.25).toFixed(2))))}
                aria-label="Alejar imagen"
                className="rounded-md border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-50"
              >
                <ZoomOut className="h-4 w-4" />
              </button>
              <span className="px-1.5 text-xs font-mono tabular-nums text-slate-600">
                {Math.round(zoom * 100)}%
              </span>
              <button
                type="button"
                onClick={() => setZoom((z) => Math.min(2.75, Number((z + 0.25).toFixed(2))))}
                aria-label="Acercar imagen"
                className="rounded-md border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-50"
              >
                <ZoomIn className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setRotation((r) => (r + 90) % 360)}
                aria-label="Rotar imagen 90 grados"
                className="rounded-md border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-50"
              >
                <RotateCw className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="relative h-80 w-full overflow-auto rounded-lg border border-slate-200 bg-slate-900/95 flex items-center justify-center p-2">
            <img
              src={activeImage.dataUrl}
              alt={`Vista previa de ${activeImage.name}`}
              referrerPolicy="no-referrer"
              style={{
                transform: `scale(${zoom}) rotate(${rotation}deg)`,
                transformOrigin: 'center center',
              }}
              className="max-h-full max-w-full object-contain transition-transform duration-150"
            />
          </div>

          {activeImage.notes && (
            <p className="mt-2.5 text-xs text-slate-600">
              Observación OCR: {activeImage.notes}
            </p>
          )}
        </div>
      )}
    </aside>
  );
}
