import React from 'react';
import {
  ChevronDown,
  ChevronUp,
  Trash2,
  User,
  UserPlus,
} from 'lucide-react';
import { DOCUMENT_TYPE_OPTIONS } from '../data/catalogs';
import type { DocumentType, FieldProvenance, OwnerRecord } from '../types/ocr';

interface OwnerSectionProps {
  owners: OwnerRecord[];
  fieldSources: FieldProvenance;
  hasExtracted: boolean;
  onAddCoOwner: () => void;
  onRemoveCoOwner: (id: string) => void;
  onToggleMinimize: (id: string) => void;
  onUpdateOwner: (id: string, patch: Partial<OwnerRecord>) => void;
}

export function OwnerSection({
  owners,
  fieldSources,
  hasExtracted,
  onAddCoOwner,
  onRemoveCoOwner,
  onToggleMinimize,
  onUpdateOwner,
}: OwnerSectionProps) {
  return (
    <section aria-labelledby="owners-heading" className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <h2 id="owners-heading" className="text-lg font-semibold text-slate-900">
            Propietario / Copropietarios
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Datos del titular principal y copropietarios vinculados al contrato.
          </p>
        </div>

        <button
          type="button"
          onClick={onAddCoOwner}
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
        >
          <UserPlus className="h-3.5 w-3.5 text-blue-700" />
          Agregar Copropietario
        </button>
      </div>

      <div className="space-y-4">
        {owners.map((owner, index) => {
          const isPrincipal = index === 0;
          const title = isPrincipal
            ? 'Propietario Principal:'
            : `Copropietario ${index}:`;

          return (
            <div
              key={owner.id}
              data-testid={`owner-card-${index}`}
              className="rounded-xl border border-slate-200 bg-white overflow-hidden"
            >
              <div className="flex items-center justify-between gap-3 bg-slate-50/70 px-4 py-3 border-b border-slate-200/80">
                <div className="flex items-center gap-2 min-w-0">
                  <User className="h-4 w-4 text-slate-600 shrink-0" />
                  <h3 className="text-sm font-semibold text-slate-900 truncate">
                    {title}
                  </h3>
                  {owner.minimized && owner.nombresYApellidos && (
                    <span className="text-xs text-slate-500 truncate">
                      {owner.nombresYApellidos}
                      {owner.identificacion ? ` · ${owner.identificacion}` : ''}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {!isPrincipal && (
                    <button
                      type="button"
                      onClick={() => onRemoveCoOwner(owner.id)}
                      aria-label={`Eliminar Copropietario ${index}`}
                      className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-rose-600 hover:bg-rose-50 transition-colors whitespace-nowrap shrink-0"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      Eliminar
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => onToggleMinimize(owner.id)}
                    aria-expanded={!owner.minimized}
                    className="inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium text-slate-600 hover:bg-slate-200/60 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
                  >
                    {owner.minimized ? (
                      <>
                        Expandir
                        <ChevronDown className="h-3.5 w-3.5" />
                      </>
                    ) : (
                      <>
                        Minimizar
                        <ChevronUp className="h-3.5 w-3.5" />
                      </>
                    )}
                  </button>
                </div>
              </div>

              {!owner.minimized && (
                <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* NOMBRES Y APELLIDOS */}
                  <div className="md:col-span-2 flex flex-col gap-1.5">
                    <div className="flex items-baseline justify-between gap-2">
                      <label
                        htmlFor={`${owner.id}-nombres`}
                        className="text-xs font-semibold tracking-wide text-slate-700"
                      >
                        NOMBRES Y APELLIDOS <span className="text-rose-600">*</span>
                      </label>
                      {isPrincipal && fieldSources.nombresYApellidos && (
                        <span className="text-[11px] font-medium text-slate-500">
                          Fuente: {fieldSources.nombresYApellidos}
                        </span>
                      )}
                    </div>
                    <input
                      id={`${owner.id}-nombres`}
                      type="text"
                      value={owner.nombresYApellidos}
                      onChange={(e) =>
                        onUpdateOwner(owner.id, {
                          nombresYApellidos: e.target.value.toUpperCase(),
                        })
                      }
                      placeholder="Ej. ABEL DARIO AMAYA HIDALGO"
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                    />
                  </div>

                  {/* TIPO DE DOCUMENTO */}
                  <div className="flex flex-col gap-1.5">
                    <label
                      htmlFor={`${owner.id}-tipo-doc`}
                      className="text-xs font-semibold tracking-wide text-slate-700"
                    >
                      TIPO DE DOCUMENTO
                    </label>
                    <select
                      id={`${owner.id}-tipo-doc`}
                      value={owner.tipoDocumento}
                      onChange={(e) =>
                        onUpdateOwner(owner.id, {
                          tipoDocumento: e.target.value as DocumentType,
                        })
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                    >
                      {DOCUMENT_TYPE_OPTIONS.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* IDENTIFICACIÓN */}
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-baseline justify-between gap-2">
                      <label
                        htmlFor={`${owner.id}-identificacion`}
                        className="text-xs font-semibold tracking-wide text-slate-700"
                      >
                        IDENTIFICACIÓN <span className="text-rose-600">*</span>
                      </label>
                      {isPrincipal && fieldSources.identificacion && (
                        <span className="text-[11px] font-medium text-slate-500">
                          Fuente: {fieldSources.identificacion}
                        </span>
                      )}
                    </div>
                    <input
                      id={`${owner.id}-identificacion`}
                      type="text"
                      value={owner.identificacion}
                      onChange={(e) =>
                        onUpdateOwner(owner.id, {
                          identificacion: e.target.value.trim().toUpperCase(),
                        })
                      }
                      placeholder="Ej. 79897980"
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono tabular-nums text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                    />
                  </div>

                  {/* TELÉFONO */}
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-baseline justify-between gap-2">
                      <label
                        htmlFor={`${owner.id}-telefono`}
                        className="text-xs font-semibold tracking-wide text-slate-700"
                      >
                        TELÉFONO
                      </label>
                      {hasExtracted && !owner.telefono && (
                        <span className="text-[11px] font-medium text-amber-700">
                          Completar manual
                        </span>
                      )}
                    </div>
                    <input
                      id={`${owner.id}-telefono`}
                      type="tel"
                      value={owner.telefono}
                      onChange={(e) =>
                        onUpdateOwner(owner.id, { telefono: e.target.value })
                      }
                      placeholder="Ej. 300 123 4567"
                      className={`w-full rounded-lg border bg-white px-3 py-2 font-mono tabular-nums text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
                        hasExtracted && !owner.telefono
                          ? 'border-amber-300 bg-amber-50/20'
                          : 'border-slate-300'
                      }`}
                    />
                  </div>

                  {/* CORREO ELECTRÓNICO */}
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-baseline justify-between gap-2">
                      <label
                        htmlFor={`${owner.id}-correo`}
                        className="text-xs font-semibold tracking-wide text-slate-700"
                      >
                        CORREO ELECTRÓNICO
                      </label>
                      {hasExtracted && !owner.correo && (
                        <span className="text-[11px] font-medium text-amber-700">
                          Completar manual
                        </span>
                      )}
                    </div>
                    <input
                      id={`${owner.id}-correo`}
                      type="email"
                      value={owner.correo}
                      onChange={(e) =>
                        onUpdateOwner(owner.id, { correo: e.target.value })
                      }
                      placeholder="ejemplo@correo.com"
                      className={`w-full rounded-lg border bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
                        hasExtracted && !owner.correo
                          ? 'border-amber-300 bg-amber-50/20'
                          : 'border-slate-300'
                      }`}
                    />
                  </div>

                  {/* DIRECCIÓN (Principal / Notificaciones) */}
                  {isPrincipal && (
                    <div className="md:col-span-2 flex flex-col gap-1.5">
                      <div className="flex items-baseline justify-between gap-2">
                        <label
                          htmlFor={`${owner.id}-direccion`}
                          className="text-xs font-semibold tracking-wide text-slate-700"
                        >
                          DIRECCIÓN (General del Vehículo / Notificaciones)
                        </label>
                        {hasExtracted && !owner.direccion && (
                          <span className="text-[11px] font-medium text-amber-700">
                            Completar manual
                          </span>
                        )}
                      </div>
                      <input
                        id={`${owner.id}-direccion`}
                        type="text"
                        value={owner.direccion}
                        onChange={(e) =>
                          onUpdateOwner(owner.id, { direccion: e.target.value })
                        }
                        placeholder="Ej. Calle 100 # 15-20"
                        className={`w-full rounded-lg border bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
                          hasExtracted && !owner.direccion
                            ? 'border-amber-300 bg-amber-50/20'
                            : 'border-slate-300'
                        }`}
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
