import React, { useState } from 'react';
import { Check, Copy, Download, Printer, X } from 'lucide-react';
import type {
  CrossValidationSummary,
  ExtraVehicleMetadata,
  OwnerRecord,
  VehicleRecord,
} from '../types/ocr';
import { generateContractSummaryText } from '../utils/ocrNormalizer';

interface ContractModalProps {
  open: boolean;
  onClose: () => void;
  owners: OwnerRecord[];
  vehicle: VehicleRecord;
  extraMetadata: ExtraVehicleMetadata;
  crossValidation: CrossValidationSummary;
}

export function ContractModal({
  open,
  onClose,
  owners,
  vehicle,
  extraMetadata,
  crossValidation,
}: ContractModalProps) {
  const [copied, setCopied] = useState(false);

  if (!open) return null;

  const principal = owners[0];
  const coOwners = owners.slice(1);
  const todayFormatted = new Date().toLocaleDateString('es-CO', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const handleCopyText = async () => {
    const text = generateContractSummaryText(owners, vehicle, extraMetadata);
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadJson = () => {
    const payload = {
      generatedAt: new Date().toISOString(),
      owners,
      vehicle,
      extraMetadata,
      crossValidation,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `contrato_${vehicle.placa || 'vehiculo'}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="contract-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 overflow-y-auto"
    >
      <div className="print-only-contract relative w-full max-w-3xl rounded-xl border border-slate-200 bg-white shadow-2xl overflow-hidden my-auto">
        {/* Toolbar */}
        <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 bg-slate-50 px-6 py-4">
          <div className="min-w-0">
            <h2
              id="contract-modal-title"
              className="text-base font-semibold text-slate-900 truncate"
            >
              Contrato Generado · Placa {vehicle.placa || 'SIN PLACA'}
            </h2>
            <p className="text-xs text-slate-500">
              Documento listo para revisión, impresión o descarga en PDF.
            </p>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleCopyText}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-600" />
                  Copiado
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  Copiar Texto
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleDownloadJson}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              JSON
            </button>

            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap shrink-0"
            >
              <Printer className="h-3.5 w-3.5" />
              Imprimir / PDF
            </button>

            <button
              type="button"
              onClick={onClose}
              aria-label="Cerrar vista de contrato"
              className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-200/70 hover:text-slate-900"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="max-h-[75vh] overflow-y-auto p-8 space-y-6 text-sm text-slate-800 leading-relaxed">
          <div className="border-b border-slate-300 pb-4 text-center">
            <p className="text-xs font-semibold tracking-widest uppercase text-slate-500">
              República de Colombia · Registro de Vinculación Automotor
            </p>
            <h3 className="mt-1 text-xl font-bold text-slate-950">
              CONTRATO DE VINCULACIÓN Y FICHA TÉCNICA DE VEHÍCULO
            </h3>
            <p className="mt-1 text-xs text-slate-500">
              Fecha de expedición: {todayFormatted}
            </p>
          </div>

          {/* Section 1: Owners */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
              1. Identificación del Propietario y Copropietarios
            </h4>

            {principal && (
              <div className="rounded-lg border border-slate-200 p-4 space-y-1.5">
                <p className="font-semibold text-slate-900">
                  Propietario Principal: {principal.nombresYApellidos}
                </p>
                <p className="text-xs text-slate-600">
                  {principal.tipoDocumento} N°{' '}
                  <span className="font-mono font-semibold text-slate-900">
                    {principal.identificacion}
                  </span>
                  {' · '}Tel: {principal.telefono || 'No registrado'}
                  {' · '}Correo: {principal.correo || 'No registrado'}
                </p>
                <p className="text-xs text-slate-600">
                  Dirección de notificaciones:{' '}
                  <span className="text-slate-900">
                    {principal.direccion || 'No registrada'}
                  </span>
                </p>
              </div>
            )}

            {coOwners.map((co, idx) => (
              <div
                key={co.id}
                className="rounded-lg border border-slate-200 p-4 space-y-1"
              >
                <p className="font-semibold text-slate-900">
                  Copropietario {idx + 1}: {co.nombresYApellidos}
                </p>
                <p className="text-xs text-slate-600">
                  {co.tipoDocumento} N°{' '}
                  <span className="font-mono font-semibold text-slate-900">
                    {co.identificacion}
                  </span>
                  {' · '}Tel: {co.telefono || 'No registrado'}
                  {' · '}Correo: {co.correo || 'No registrado'}
                </p>
              </div>
            ))}
          </div>

          {/* Section 2: Vehicle Specs */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
              2. Características del Vehículo
            </h4>

            <div className="overflow-hidden rounded-lg border border-slate-200">
              <table className="w-full text-left text-xs">
                <tbody className="divide-y divide-slate-200">
                  <tr>
                    <th className="w-40 bg-slate-50 px-3 py-2 font-semibold text-slate-600">
                      Placa
                    </th>
                    <td className="px-3 py-2 font-mono font-semibold text-slate-900">
                      {vehicle.placa}
                    </td>
                    <th className="w-40 bg-slate-50 px-3 py-2 font-semibold text-slate-600">
                      Modelo (Año)
                    </th>
                    <td className="px-3 py-2 font-mono text-slate-900">
                      {vehicle.modelo || 'N/A'}
                    </td>
                  </tr>
                  <tr>
                    <th className="bg-slate-50 px-3 py-2 font-semibold text-slate-600">
                      Marca / Línea
                    </th>
                    <td className="px-3 py-2 text-slate-900">
                      {vehicle.marca} {vehicle.linea}
                    </td>
                    <th className="bg-slate-50 px-3 py-2 font-semibold text-slate-600">
                      Clase / Carrocería
                    </th>
                    <td className="px-3 py-2 text-slate-900">
                      {vehicle.clase} · {vehicle.carroceria || 'N/A'}
                    </td>
                  </tr>
                  <tr>
                    <th className="bg-slate-50 px-3 py-2 font-semibold text-slate-600">
                      N° Motor
                    </th>
                    <td className="px-3 py-2 font-mono text-slate-900">
                      {vehicle.numeroMotor}
                    </td>
                    <th className="bg-slate-50 px-3 py-2 font-semibold text-slate-600">
                      N° Serie
                    </th>
                    <td className="px-3 py-2 font-mono text-slate-900">
                      {vehicle.numeroSerie}
                    </td>
                  </tr>
                  <tr>
                    <th className="bg-slate-50 px-3 py-2 font-semibold text-slate-600">
                      N° Chasis
                    </th>
                    <td className="px-3 py-2 font-mono text-slate-900">
                      {vehicle.numeroChasis || 'N/A'}
                    </td>
                    <th className="bg-slate-50 px-3 py-2 font-semibold text-slate-600">
                      Cilindraje / Combustible
                    </th>
                    <td className="px-3 py-2 text-slate-900">
                      {vehicle.cilindraje ? `${vehicle.cilindraje} cc` : 'N/A'} ·{' '}
                      {vehicle.combustible || 'N/A'}
                    </td>
                  </tr>
                  <tr>
                    <th className="bg-slate-50 px-3 py-2 font-semibold text-slate-600">
                      Empresa de Taxi Actual
                    </th>
                    <td colSpan={3} className="px-3 py-2 font-semibold text-slate-900">
                      {vehicle.empresaTaxiActual || 'NINGUNA / VEHÍCULO NUEVO'}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 3: Support Docs */}
          {(extraMetadata.licenciaTransitoNo ||
            extraMetadata.tarjetaOperacionNo ||
            extraMetadata.limitacionPropiedad) && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                3. Soporte Documental Verificado
              </h4>
              <div className="rounded-lg border border-slate-200 p-4 text-xs text-slate-700 space-y-1">
                {extraMetadata.licenciaTransitoNo && (
                  <p>
                    Licencia de Tránsito (TP) No.:{' '}
                    <strong className="font-mono">{extraMetadata.licenciaTransitoNo}</strong>
                    {extraMetadata.organismoTransito
                      ? ` · Organismo: ${extraMetadata.organismoTransito}`
                      : ''}
                  </p>
                )}
                {extraMetadata.tarjetaOperacionNo && (
                  <p>
                    Tarjeta de Operación No.:{' '}
                    <strong className="font-mono">{extraMetadata.tarjetaOperacionNo}</strong>
                    {extraMetadata.tarjetaOperacionVencimiento
                      ? ` · Vence: ${extraMetadata.tarjetaOperacionVencimiento}`
                      : ''}
                  </p>
                )}
                {extraMetadata.limitacionPropiedad && (
                  <p>
                    Limitación a la Propiedad:{' '}
                    <strong>{extraMetadata.limitacionPropiedad}</strong>
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Signatures */}
          <div className="pt-8 grid grid-cols-2 gap-8 text-xs text-slate-600">
            <div className="border-t border-slate-400 pt-2">
              <p className="font-semibold text-slate-900">
                {principal?.nombresYApellidos || 'PROPIETARIO PRINCIPAL'}
              </p>
              <p>
                {principal?.tipoDocumento || 'CC'} N°{' '}
                {principal?.identificacion || '____________'}
              </p>
            </div>
            <div className="border-t border-slate-400 pt-2">
              <p className="font-semibold text-slate-900">
                Representante / Empresa Vinculadora
              </p>
              <p>Firma y Sello Autorizado</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
