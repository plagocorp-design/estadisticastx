import React from 'react';

const MAPPING_RULES = [
  {
    field: 'NOMBRES Y APELLIDOS / IDENTIFICACIÓN',
    source: 'Cédula de Ciudadanía (CC) y Licencia de Tránsito (TP)',
    note: 'Se normaliza en orden Nombres + Apellidos y se valida que el número de documento sin puntos coincida con el propietario en la TP.',
  },
  {
    field: 'N° MOTOR / N° SERIE / N° CHASIS',
    source: 'Licencia de Tránsito / Tarjeta de Propiedad (TP)',
    note: 'Campos críticos marcados con *Validar con TP. El N° de Serie y N° de Chasis solo aparecen en la TP, nunca en la Tarjeta de Operación.',
  },
  {
    field: 'LÍNEA / CILINDRAJE / CLASE',
    source: 'Licencia de Tránsito (TP)',
    note: 'La TP define la línea exacta (ej. SPARK), la cilindrada (normalizada de 1.000 a 1000) y la clase oficial (AUTOMOVIL).',
  },
  {
    field: 'EMPRESA DE TAXI ACTUAL',
    source: 'Tarjeta de Operación (TO)',
    note: 'Se extrae del campo Razón Social de la Tarjeta de Operación vigente (ej. TAXEXPRESS SA). Si es vehículo nuevo, queda NINGUNA / VEHÍCULO NUEVO.',
  },
  {
    field: 'COMBUSTIBLE',
    source: 'Licencia de Tránsito (TP) y Tarjeta de Operación (TO)',
    note: 'Codificaciones como GASGASOL o GAS GASOL se unifican automáticamente como GAS / GASOLINA.',
  },
  {
    field: 'TELÉFONO / CORREO / DIRECCIÓN',
    source: 'Diligenciamiento manual o RUNT',
    note: 'Estos datos no figuran en Cédula, TP ni Tarjeta de Operación; el formulario resalta los campos pendientes para completar antes de imprimir.',
  },
];

export function RulesView() {
  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <div className="border-b border-slate-200 pb-4">
        <h2 className="text-xl font-semibold text-slate-900">
          Reglas de Extracción y Validación TP / TO
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Criterios automáticos empleados al procesar fotografías de documentos vehiculares en Colombia.
        </p>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="min-w-[620px] w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
            <tr>
              <th className="px-4 py-3">Campo del Formulario</th>
              <th className="px-4 py-3">Documento Fuente Prioritario</th>
              <th className="px-4 py-3">Regla de Validación y Normalización</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {MAPPING_RULES.map((row) => (
              <tr key={row.field} className="align-top">
                <td className="px-4 py-3.5 font-semibold text-xs text-slate-900">
                  {row.field}
                </td>
                <td className="px-4 py-3.5 text-xs font-medium text-blue-800">
                  {row.source}
                </td>
                <td className="px-4 py-3.5 text-xs text-slate-600 leading-relaxed">
                  {row.note}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
