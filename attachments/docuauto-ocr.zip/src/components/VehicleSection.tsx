import React from 'react';
import { AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import {
  TAXI_COMPANY_OPTIONS,
  VEHICLE_BODY_OPTIONS,
  VEHICLE_BRAND_OPTIONS,
  VEHICLE_CLASS_OPTIONS,
  VEHICLE_FUEL_OPTIONS,
  VEHICLE_LINE_OPTIONS,
} from '../data/catalogs';
import type {
  CrossValidationSummary,
  ExtraVehicleMetadata,
  FieldProvenance,
  VehicleRecord,
} from '../types/ocr';
import { ComboboxField } from './ComboboxField';

interface VehicleSectionProps {
  vehicle: VehicleRecord;
  extraMetadata: ExtraVehicleMetadata;
  crossValidation: CrossValidationSummary;
  fieldSources: FieldProvenance;
  hasExtracted: boolean;
  onUpdateVehicle: (patch: Partial<VehicleRecord>) => void;
  onUpdateExtra: (patch: Partial<ExtraVehicleMetadata>) => void;
}

export function VehicleSection({
  vehicle,
  extraMetadata,
  crossValidation,
  fieldSources,
  hasExtracted,
  onUpdateVehicle,
  onUpdateExtra,
}: VehicleSectionProps) {
  const sourceLabel = (key: string) =>
    fieldSources[key] ? `Fuente: ${fieldSources[key]}` : undefined;

  return (
    <section aria-labelledby="vehicle-heading" className="space-y-5">
      <div className="border-b border-slate-200 pb-3">
        <h2 id="vehicle-heading" className="text-lg font-semibold text-slate-900">
          Características del Vehículo
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Los campos marcados con *Validar con TP se confrontan directamente contra la Licencia de Tránsito.
        </p>
      </div>

      {/* Cross-Validation Alerts */}
      {hasExtracted && crossValidation.alerts.length > 0 && (
        <div
          role="alert"
          className="rounded-lg border border-amber-200 bg-amber-50/70 p-3.5 text-xs text-amber-900 space-y-1"
        >
          <div className="flex items-center gap-2 font-semibold">
            <AlertTriangle className="h-4 w-4 text-amber-700 shrink-0" />
            <span>Observaciones de Validación Documental</span>
          </div>
          <ul className="list-disc pl-5 space-y-0.5">
            {crossValidation.alerts.map((alertText, i) => (
              <li key={i}>{alertText}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="rounded-xl border border-slate-200 bg-white p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* PLACA */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-baseline justify-between gap-2">
            <label
              htmlFor="veh-placa"
              className="text-xs font-semibold tracking-wide text-slate-700"
            >
              PLACA <span className="text-rose-600">*</span>
            </label>
            {fieldSources.placa && (
              <span className="text-[11px] font-medium text-slate-500">
                {sourceLabel('placa')}
              </span>
            )}
          </div>
          <input
            id="veh-placa"
            type="text"
            value={vehicle.placa}
            onChange={(e) =>
              onUpdateVehicle({
                placa: e.target.value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase(),
              })
            }
            placeholder="Ej. TUX123"
            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono font-semibold tracking-wider uppercase text-sm text-slate-900 placeholder:font-sans placeholder:font-normal placeholder:tracking-normal placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
          />
        </div>

        {/* MARCA */}
        <ComboboxField
          id="veh-marca"
          label="MARCA"
          required
          value={vehicle.marca}
          onChange={(val) => onUpdateVehicle({ marca: val })}
          options={VEHICLE_BRAND_OPTIONS}
          placeholder="Seleccione o escriba..."
          sourceHint={sourceLabel('marca')}
        />

        {/* LÍNEA */}
        <ComboboxField
          id="veh-linea"
          label="LÍNEA"
          value={vehicle.linea}
          onChange={(val) => onUpdateVehicle({ linea: val })}
          options={VEHICLE_LINE_OPTIONS}
          placeholder="Seleccione o escriba..."
          sourceHint={sourceLabel('linea')}
        />

        {/* CLASE */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-baseline justify-between gap-2">
            <label
              htmlFor="veh-clase"
              className="text-xs font-semibold tracking-wide text-slate-700"
            >
              CLASE
            </label>
            {fieldSources.clase && (
              <span className="text-[11px] font-medium text-slate-500">
                {sourceLabel('clase')}
              </span>
            )}
          </div>
          <select
            id="veh-clase"
            value={vehicle.clase}
            onChange={(e) => onUpdateVehicle({ clase: e.target.value })}
            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
          >
            {VEHICLE_CLASS_OPTIONS.map((cls) => (
              <option key={cls} value={cls}>
                {cls}
              </option>
            ))}
            {vehicle.clase && !VEHICLE_CLASS_OPTIONS.includes(vehicle.clase) && (
              <option value={vehicle.clase}>{vehicle.clase}</option>
            )}
          </select>
        </div>

        {/* MODELO (Año) */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-baseline justify-between gap-2">
            <label
              htmlFor="veh-modelo"
              className="text-xs font-semibold tracking-wide text-slate-700"
            >
              MODELO (Año)
            </label>
            {fieldSources.modelo && (
              <span className="text-[11px] font-medium text-slate-500">
                {sourceLabel('modelo')}
              </span>
            )}
          </div>
          <input
            id="veh-modelo"
            type="text"
            inputMode="numeric"
            maxLength={4}
            value={vehicle.modelo}
            onChange={(e) =>
              onUpdateVehicle({
                modelo: e.target.value.replace(/[^0-9]/g, '').slice(0, 4),
              })
            }
            placeholder="Ej. 2024"
            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono tabular-nums text-sm text-slate-900 placeholder:font-sans placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
          />
        </div>

        {/* CILINDRAJE */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-baseline justify-between gap-2">
            <label
              htmlFor="veh-cilindraje"
              className="text-xs font-semibold tracking-wide text-slate-700"
            >
              CILINDRAJE
            </label>
            {fieldSources.cilindraje && (
              <span className="text-[11px] font-medium text-slate-500">
                {sourceLabel('cilindraje')}
              </span>
            )}
          </div>
          <input
            id="veh-cilindraje"
            type="text"
            inputMode="numeric"
            value={vehicle.cilindraje}
            onChange={(e) =>
              onUpdateVehicle({
                cilindraje: e.target.value.replace(/[^0-9]/g, ''),
              })
            }
            placeholder="Ej. 1600"
            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono tabular-nums text-sm text-slate-900 placeholder:font-sans placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
          />
        </div>

        {/* N° MOTOR *Validar con TP */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-baseline justify-between gap-2">
            <label
              htmlFor="veh-motor"
              className="text-xs font-semibold tracking-wide text-slate-700"
            >
              N° MOTOR <span className="text-amber-700 font-medium">*Validar con TP</span>
            </label>
            {hasExtracted && (
              <span
                className={`inline-flex items-center gap-1 text-[11px] font-semibold ${
                  crossValidation.motorValidadoConTP
                    ? 'text-emerald-700'
                    : 'text-amber-700'
                }`}
              >
                {crossValidation.motorValidadoConTP ? (
                  <>
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Validado TP
                  </>
                ) : (
                  'Revisar TP'
                )}
              </span>
            )}
          </div>
          <input
            id="veh-motor"
            type="text"
            value={vehicle.numeroMotor}
            onChange={(e) =>
              onUpdateVehicle({
                numeroMotor: e.target.value.replace(/\s+/g, '').toUpperCase(),
              })
            }
            placeholder="Ingrese número de motor"
            className={`w-full rounded-lg border bg-white px-3 py-2 font-mono text-sm text-slate-900 placeholder:font-sans placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
              hasExtracted && crossValidation.motorValidadoConTP
                ? 'border-emerald-300'
                : 'border-slate-300'
            }`}
          />
        </div>

        {/* N° SERIE *Validar con TP */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-baseline justify-between gap-2">
            <label
              htmlFor="veh-serie"
              className="text-xs font-semibold tracking-wide text-slate-700"
            >
              N° SERIE <span className="text-amber-700 font-medium">*Validar con TP</span>
            </label>
            {hasExtracted && (
              <span
                className={`inline-flex items-center gap-1 text-[11px] font-semibold ${
                  crossValidation.serieValidadaConTP
                    ? 'text-emerald-700'
                    : 'text-amber-700'
                }`}
              >
                {crossValidation.serieValidadaConTP ? (
                  <>
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Validado TP
                  </>
                ) : (
                  'Revisar TP'
                )}
              </span>
            )}
          </div>
          <input
            id="veh-serie"
            type="text"
            value={vehicle.numeroSerie}
            onChange={(e) =>
              onUpdateVehicle({
                numeroSerie: e.target.value.replace(/\s+/g, '').toUpperCase(),
              })
            }
            placeholder="Ingrese número de serie"
            className={`w-full rounded-lg border bg-white px-3 py-2 font-mono text-sm text-slate-900 placeholder:font-sans placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
              hasExtracted && crossValidation.serieValidadaConTP
                ? 'border-emerald-300'
                : 'border-slate-300'
            }`}
          />
        </div>

        {/* CARROCERÍA */}
        <ComboboxField
          id="veh-carroceria"
          label="CARROCERÍA"
          value={vehicle.carroceria}
          onChange={(val) => onUpdateVehicle({ carroceria: val })}
          options={VEHICLE_BODY_OPTIONS}
          placeholder="Seleccione o escriba..."
          sourceHint={sourceLabel('carroceria')}
        />

        {/* N° CHASIS */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-baseline justify-between gap-2">
            <label
              htmlFor="veh-chasis"
              className="text-xs font-semibold tracking-wide text-slate-700"
            >
              N° CHASIS
            </label>
            {fieldSources.numeroChasis && (
              <span className="text-[11px] font-medium text-slate-500">
                {sourceLabel('numeroChasis')}
              </span>
            )}
          </div>
          <input
            id="veh-chasis"
            type="text"
            value={vehicle.numeroChasis}
            onChange={(e) =>
              onUpdateVehicle({
                numeroChasis: e.target.value.replace(/\s+/g, '').toUpperCase(),
              })
            }
            placeholder="Ingrese el chasis"
            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900 placeholder:font-sans placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
          />
        </div>

        {/* COMBUSTIBLE */}
        <ComboboxField
          id="veh-combustible"
          label="COMBUSTIBLE"
          value={vehicle.combustible}
          onChange={(val) => onUpdateVehicle({ combustible: val })}
          options={VEHICLE_FUEL_OPTIONS}
          placeholder="Seleccione o escriba..."
          sourceHint={sourceLabel('combustible')}
        />

        {/* EMPRESA DE TAXI ACTUAL */}
        <ComboboxField
          id="veh-empresa-taxi"
          label="EMPRESA DE TAXI ACTUAL"
          value={vehicle.empresaTaxiActual}
          onChange={(val) => onUpdateVehicle({ empresaTaxiActual: val })}
          options={TAXI_COMPANY_OPTIONS}
          placeholder="NINGUNA / VEHÍCULO NUEVO"
          sourceHint={sourceLabel('empresaTaxiActual')}
        />
      </div>

      {/* Extra Extracted Document Metadata (TP / TO) */}
      {(extraMetadata.tarjetaOperacionNo ||
        extraMetadata.licenciaTransitoNo ||
        extraMetadata.limitacionPropiedad ||
        extraMetadata.color) && (
        <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-800 mb-3">
            <Info className="h-4 w-4 text-blue-700" />
            <span>Soporte Documental Detectado (TP y Tarjeta de Operación)</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <label htmlFor="meta-tp" className="block text-slate-500 mb-1">
                N° Licencia Tránsito (TP)
              </label>
              <input
                id="meta-tp"
                type="text"
                value={extraMetadata.licenciaTransitoNo}
                onChange={(e) =>
                  onUpdateExtra({ licenciaTransitoNo: e.target.value })
                }
                className="w-full rounded border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-slate-800"
              />
            </div>

            <div>
              <label htmlFor="meta-to" className="block text-slate-500 mb-1">
                Tarjeta de Operación No.
              </label>
              <input
                id="meta-to"
                type="text"
                value={extraMetadata.tarjetaOperacionNo}
                onChange={(e) =>
                  onUpdateExtra({ tarjetaOperacionNo: e.target.value })
                }
                className="w-full rounded border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-slate-800"
              />
            </div>

            <div>
              <label htmlFor="meta-vence" className="block text-slate-500 mb-1">
                Vencimiento TO
              </label>
              <input
                id="meta-vence"
                type="text"
                value={extraMetadata.tarjetaOperacionVencimiento}
                onChange={(e) =>
                  onUpdateExtra({ tarjetaOperacionVencimiento: e.target.value })
                }
                className="w-full rounded border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-slate-800"
              />
            </div>

            <div>
              <label htmlFor="meta-color" className="block text-slate-500 mb-1">
                Color
              </label>
              <input
                id="meta-color"
                type="text"
                value={extraMetadata.color}
                onChange={(e) =>
                  onUpdateExtra({ color: e.target.value.toUpperCase() })
                }
                className="w-full rounded border border-slate-200 bg-white px-2.5 py-1.5 text-slate-800"
              />
            </div>

            <div>
              <label htmlFor="meta-servicio" className="block text-slate-500 mb-1">
                Servicio
              </label>
              <input
                id="meta-servicio"
                type="text"
                value={extraMetadata.servicio}
                onChange={(e) =>
                  onUpdateExtra({ servicio: e.target.value.toUpperCase() })
                }
                className="w-full rounded border border-slate-200 bg-white px-2.5 py-1.5 text-slate-800"
              />
            </div>

            <div>
              <label htmlFor="meta-organismo" className="block text-slate-500 mb-1">
                Organismo Tránsito
              </label>
              <input
                id="meta-organismo"
                type="text"
                value={extraMetadata.organismoTransito}
                onChange={(e) =>
                  onUpdateExtra({
                    organismoTransito: e.target.value.toUpperCase(),
                  })
                }
                className="w-full rounded border border-slate-200 bg-white px-2.5 py-1.5 text-slate-800"
              />
            </div>

            {extraMetadata.limitacionPropiedad && (
              <div className="col-span-2 sm:col-span-3">
                <label htmlFor="meta-prenda" className="block text-slate-500 mb-1">
                  Limitación a la Propiedad / Prenda
                </label>
                <input
                  id="meta-prenda"
                  type="text"
                  value={extraMetadata.limitacionPropiedad}
                  onChange={(e) =>
                    onUpdateExtra({
                      limitacionPropiedad: e.target.value.toUpperCase(),
                    })
                  }
                  className="w-full rounded border border-amber-200 bg-white px-2.5 py-1.5 font-medium text-amber-900"
                />
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
