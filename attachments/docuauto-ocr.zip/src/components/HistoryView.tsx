import React, { useState } from 'react';
import { FolderOpen, Search, Trash2 } from 'lucide-react';
import type { SavedRecord } from '../types/ocr';

interface HistoryViewProps {
  records: SavedRecord[];
  onLoadRecord: (record: SavedRecord) => void;
  onDeleteRecord: (id: string) => void;
}

export function HistoryView({
  records,
  onLoadRecord,
  onDeleteRecord,
}: HistoryViewProps) {
  const [query, setQuery] = useState('');

  const filtered = records.filter((rec) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    const ownerNames = rec.owners.map((o) => o.nombresYApellidos.toLowerCase()).join(' ');
    return (
      rec.vehicle.placa.toLowerCase().includes(q) ||
      ownerNames.includes(q) ||
      rec.vehicle.empresaTaxiActual.toLowerCase().includes(q)
    );
  });

  return (
    <div className="mx-auto max-w-5xl space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">
            Historial de Trámites y Contratos
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Registros guardados localmente al generar contratos o completar extracciones.
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar por placa o propietario..."
            aria-label="Buscar en el historial"
            className="w-full rounded-lg border border-slate-300 bg-white pl-9 pr-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
          <p className="text-sm font-medium text-slate-800">
            {records.length === 0
              ? 'Aún no hay contratos guardados en el historial.'
              : 'No se encontraron trámites que coincidan con su búsqueda.'}
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Al hacer clic en "Generar Contrato" en el Espacio de Trabajo, el trámite se archivará aquí automáticamente.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
          <table className="min-w-[680px] w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
              <tr>
                <th className="px-4 py-3">Placa</th>
                <th className="px-4 py-3">Propietario Principal</th>
                <th className="px-4 py-3">Vehículo</th>
                <th className="px-4 py-3">Empresa Actual</th>
                <th className="px-4 py-3">Fecha</th>
                <th className="px-4 py-3 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((rec) => {
                const principal = rec.owners[0];
                return (
                  <tr key={rec.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-3 font-mono font-semibold text-slate-900">
                      {rec.vehicle.placa || 'N/A'}
                    </td>
                    <td className="px-4 py-3">
                      <p className="font-medium text-slate-900">
                        {principal?.nombresYApellidos || 'Sin nombre'}
                      </p>
                      <p className="text-xs font-mono text-slate-500">
                        {principal?.identificacion || ''}
                      </p>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-700">
                      {rec.vehicle.marca} {rec.vehicle.linea} · {rec.vehicle.modelo}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-700">
                      {rec.vehicle.empresaTaxiActual}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500 tabular-nums">
                      {new Date(rec.savedAt).toLocaleDateString('es-CO')}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onLoadRecord(rec)}
                          className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap shrink-0"
                        >
                          <FolderOpen className="h-3.5 w-3.5 text-blue-700" />
                          Cargar
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteRecord(rec.id)}
                          aria-label={`Eliminar trámite ${rec.vehicle.placa}`}
                          className="rounded-md p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
