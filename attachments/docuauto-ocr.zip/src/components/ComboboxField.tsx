import React, { useEffect, useId, useRef, useState } from 'react';
import { ChevronDown, X } from 'lucide-react';

interface ComboboxFieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: string[];
  placeholder?: string;
  sourceHint?: string;
  uppercase?: boolean;
  required?: boolean;
  error?: string;
}

export function ComboboxField({
  id,
  label,
  value,
  onChange,
  options,
  placeholder = 'Seleccione o escriba...',
  sourceHint,
  uppercase = true,
  required = false,
  error,
}: ComboboxFieldProps) {
  const [open, setOpen] = useState(false);
  const [filterText, setFilterText] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const listboxId = useId();

  useEffect(() => {
    const handleOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false);
        setFilterText('');
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const query = (filterText || value).trim().toLowerCase();
  const filteredOptions = query
    ? options.filter((opt) => opt.toLowerCase().includes(query))
    : options;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const next = uppercase ? e.target.value.toUpperCase() : e.target.value;
    setFilterText(next);
    onChange(next);
    if (!open) setOpen(true);
  };

  const handleSelectOption = (option: string) => {
    onChange(option);
    setFilterText('');
    setOpen(false);
  };

  return (
    <div ref={containerRef} className="relative flex flex-col gap-1.5">
      <div className="flex items-baseline justify-between gap-2">
        <label
          htmlFor={id}
          className="text-xs font-semibold tracking-wide text-slate-700"
        >
          {label}
          {required && <span className="text-rose-600 ml-0.5">*</span>}
        </label>
        {sourceHint && (
          <span className="text-[11px] font-medium text-slate-500 whitespace-nowrap">
            {sourceHint}
          </span>
        )}
      </div>

      <div className="relative flex items-center">
        <input
          id={id}
          type="text"
          role="combobox"
          aria-expanded={open}
          aria-controls={listboxId}
          aria-autocomplete="list"
          value={value}
          onChange={handleInputChange}
          onFocus={() => setOpen(true)}
          placeholder={placeholder}
          className={`w-full rounded-lg border bg-white px-3 py-2 pr-14 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
            error
              ? 'border-rose-400 focus:border-rose-500'
              : 'border-slate-300 focus:border-blue-600'
          }`}
        />

        <div className="absolute right-1.5 flex items-center gap-0.5">
          {value && (
            <button
              type="button"
              onClick={() => {
                onChange('');
                setFilterText('');
              }}
              aria-label={`Limpiar ${label}`}
              className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
          <button
            type="button"
            onClick={() => setOpen((prev) => !prev)}
            aria-label={`Desplegar opciones de ${label}`}
            className="rounded p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-800"
          >
            <ChevronDown
              className={`h-4 w-4 transition-transform duration-150 ${
                open ? 'rotate-180' : ''
              }`}
            />
          </button>
        </div>
      </div>

      {error && <p className="text-xs text-rose-600">{error}</p>}

      {open && (
        <ul
          id={listboxId}
          role="listbox"
          className="absolute top-full left-0 z-30 mt-1 max-h-52 w-full overflow-y-auto rounded-lg border border-slate-200 bg-white py-1 shadow-lg"
        >
          {filteredOptions.length > 0 ? (
            filteredOptions.map((opt) => (
              <li key={opt} role="option" aria-selected={value === opt}>
                <button
                  type="button"
                  onClick={() => handleSelectOption(opt)}
                  className={`flex w-full items-center justify-between px-3 py-2 text-left text-sm transition-colors ${
                    value === opt
                      ? 'bg-blue-50 font-medium text-blue-900'
                      : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <span className="truncate">{opt}</span>
                </button>
              </li>
            ))
          ) : (
            <li className="px-3 py-2 text-xs text-slate-500">
              Valor personalizado: <strong className="text-slate-800">{value}</strong>
            </li>
          )}
        </ul>
      )}
    </div>
  );
}
